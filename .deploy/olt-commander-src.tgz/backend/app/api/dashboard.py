from fastapi import APIRouter, Depends
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from ..database import get_db
from ..models import ArpEntry, Binding, MacEntry, MikrotikDevice, OLTDevice, Onu, ScanLog, User
from ..schemas import DashboardSummary, ScanLogOut
from ..security import get_current_user

router = APIRouter(prefix="/api", tags=["dashboard"], dependencies=[Depends(get_current_user)])


@router.get("/dashboard", response_model=DashboardSummary)
async def dashboard_summary(db: AsyncSession = Depends(get_db)):
    olt_count = (await db.execute(select(func.count(OLTDevice.id)))).scalar() or 0
    olt_reachable = (
        await db.execute(select(func.count(OLTDevice.id)).where(OLTDevice.status == "reachable"))
    ).scalar() or 0
    mkt_count = (await db.execute(select(func.count(MikrotikDevice.id)))).scalar() or 0
    onu_total = (await db.execute(select(func.count(Onu.id)))).scalar() or 0
    onu_manual = (await db.execute(select(func.count(Onu.id)).where(Onu.source == "manual"))).scalar() or 0
    onu_active = (await db.execute(select(func.count(Onu.id)).where(Onu.state == "active"))).scalar() or 0
    onu_inactive = (await db.execute(select(func.count(Onu.id)).where(Onu.state == "inactive"))).scalar() or 0
    onu_bound = (await db.execute(select(func.count(Onu.id)).where(Onu.bound.is_(True)))).scalar() or 0
    mac_count = (await db.execute(select(func.count(MacEntry.id)))).scalar() or 0
    arp_count = (await db.execute(select(func.count(ArpEntry.id)))).scalar() or 0
    matched = (await db.execute(select(func.count(Binding.id)).where(Binding.bound.is_(True)))).scalar() or 0
    last = (
        await db.execute(select(func.max(ScanLog.started_at)))
    ).scalar()

    return DashboardSummary(
        olt_count=olt_count,
        olt_reachable=olt_reachable,
        mikrotik_count=mkt_count,
        onu_total=onu_total,
        onu_manual=onu_manual,
        onu_active=onu_active,
        onu_inactive=onu_inactive,
        onu_bound=onu_bound,
        olt_mac_count=mac_count,
        arp_mac_count=arp_count,
        matched_mac_count=matched,
        last_scan=last,
    )


@router.get("/scans", response_model=list[ScanLogOut])
async def list_scans(limit: int = 50, db: AsyncSession = Depends(get_db)):
    q = select(ScanLog).order_by(ScanLog.started_at.desc()).limit(min(limit, 500))
    return (await db.execute(q)).scalars().all()