from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from ..database import get_db
from ..models import OLTDevice, Onu, OnuSource, User
from ..schemas import OnuCreate, OnuOut, OnuUpdate
from ..security import get_current_user

router = APIRouter(prefix="/api/onus", tags=["onus"], dependencies=[Depends(get_current_user)])


async def _load_onu(db: AsyncSession, onu_id: int) -> Onu:
    onu = await db.get(Onu, onu_id)
    if onu is None:
        raise HTTPException(status_code=404, detail="ONU not found")
    return onu


@router.get("", response_model=list[OnuOut])
async def list_onus(
    olt_id: int | None = Query(default=None),
    state: str | None = Query(default=None),
    source: str | None = Query(default=None),
    search: str | None = Query(default=None),
    bound: bool | None = Query(default=None),
    db: AsyncSession = Depends(get_db),
):
    q = select(Onu).options(selectinload(Onu.olt)).order_by(Onu.olt_id, Onu.pon_port, Onu.onu_id)
    if olt_id is not None:
        q = q.where(Onu.olt_id == olt_id)
    if state:
        q = q.where(Onu.state == state)
    if source:
        q = q.where(Onu.source == source)
    if bound is not None:
        q = q.where(Onu.bound.is_(bound))
    if search:
        like = f"%{search}%"
        q = q.where(
            Onu.name.ilike(like)
            | Onu.serial.ilike(like)
            | Onu.mac.ilike(like)
            | Onu.pon_port.ilike(like)
            | Onu.last_mac.ilike(like)
        )
    res = await db.execute(q)
    rows = res.scalars().all()
    return [_to_out(onu) for onu in rows]


def _to_out(onu: Onu) -> OnuOut:
    out = OnuOut.model_validate(onu)
    out.olt_name = onu.olt.name if onu.olt else ""
    return out


@router.post("", response_model=OnuOut)
async def create_onu(body: OnuCreate, db: AsyncSession = Depends(get_db)):
    """Add an ONU/ONT to the application inventory.

    This is application-only bookkeeping and never talks to the Mikrotik
    or the OLT.
    """
    olt = await db.get(OLTDevice, body.olt_id)
    if olt is None:
        raise HTTPException(status_code=404, detail="OLT not found")
    onu = Onu(olt_id=body.olt_id, source=OnuSource.manual, **body.model_dump(exclude={"olt_id"}))
    db.add(onu)
    await db.commit()
    await db.refresh(onu, attribute_names=["olt"])
    return _to_out(onu)


@router.put("/{onu_id}", response_model=OnuOut)
async def update_onu(onu_id: int, body: OnuUpdate, db: AsyncSession = Depends(get_db)):
    onu = await _load_onu(db, onu_id)
    for field, value in body.model_dump(exclude_unset=True).items():
        setattr(onu, field, value)
    await db.commit()
    await db.refresh(onu, attribute_names=["olt"])
    return _to_out(onu)


@router.delete("/{onu_id}", status_code=204)
async def delete_onu(onu_id: int, db: AsyncSession = Depends(get_db)):
    """Remove an ONU/ONT from the application.

    Application-only removal; nothing is changed on the Mikrotik or OLT.
    """
    onu = await _load_onu(db, onu_id)
    await db.delete(onu)
    await db.commit()