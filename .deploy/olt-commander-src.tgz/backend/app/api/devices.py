from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from ..database import get_db
from ..models import OLTDevice, Onu, User, MikrotikDevice
from ..schemas import (
    MikrotikCreate,
    MikrotikOut,
    MikrotikUpdate,
    OLTDeviceCreate,
    OLTDeviceOut,
    OLTDeviceUpdate,
    ScanResult,
    TestResult,
)
from ..security import get_current_user
from ..services import collector

router = APIRouter(prefix="/api/devices", tags=["devices"], dependencies=[Depends(get_current_user)])


# ------------------------------------------------------------------ OLTs
@router.get("/olts", response_model=list[OLTDeviceOut])
async def list_olts(db: AsyncSession = Depends(get_db)):
    res = await db.execute(
        select(OLTDevice, func.count(Onu.id))
        .outerjoin(Onu, Onu.olt_id == OLTDevice.id)
        .group_by(OLTDevice.id)
        .order_by(OLTDevice.id)
    )
    out = []
    for device, count in res.all():
        item = OLTDeviceOut.model_validate(device)
        item.onu_count = count
        out.append(item)
    return out


@router.post("/olts", response_model=OLTDeviceOut)
async def create_olt(body: OLTDeviceCreate, db: AsyncSession = Depends(get_db)):
    device = OLTDevice(**body.model_dump())
    db.add(device)
    await db.commit()
    await db.refresh(device)
    return device


@router.put("/olts/{olt_id}", response_model=OLTDeviceOut)
async def update_olt(olt_id: int, body: OLTDeviceUpdate, db: AsyncSession = Depends(get_db)):
    device = await db.get(OLTDevice, olt_id)
    if device is None:
        raise HTTPException(status_code=404, detail="OLT not found")
    for field, value in body.model_dump(exclude_unset=True).items():
        setattr(device, field, value)
    await db.commit()
    await db.refresh(device)
    return device


@router.delete("/olts/{olt_id}", status_code=204)
async def delete_olt(olt_id: int, db: AsyncSession = Depends(get_db)):
    device = await db.get(OLTDevice, olt_id)
    if device is None:
        raise HTTPException(status_code=404, detail="OLT not found")
    await db.delete(device)
    await db.commit()


@router.post("/olts/{olt_id}/test", response_model=TestResult)
async def test_olt(olt_id: int, db: AsyncSession = Depends(get_db)):
    try:
        message = await collector.test_olt(db, olt_id)
        return TestResult(success=True, message=message)
    except Exception as exc:
        return TestResult(success=False, message=str(exc))


@router.post("/olts/{olt_id}/scan", response_model=ScanResult)
async def scan_olt(olt_id: int, db: AsyncSession = Depends(get_db)):
    try:
        log = await collector.scan_olt(db, olt_id)
        return ScanResult(success=log.status.value == "success", message=log.message, log_id=log.id)
    except Exception as exc:
        return ScanResult(success=False, message=str(exc))


# ------------------------------------------------------------- Mikrotiks
@router.get("/mikrotiks", response_model=list[MikrotikOut])
async def list_mikrotiks(db: AsyncSession = Depends(get_db)):
    res = await db.execute(select(MikrotikDevice).order_by(MikrotikDevice.id))
    return res.scalars().all()


@router.post("/mikrotiks", response_model=MikrotikOut)
async def create_mikrotik(body: MikrotikCreate, db: AsyncSession = Depends(get_db)):
    device = MikrotikDevice(**body.model_dump())
    db.add(device)
    await db.commit()
    await db.refresh(device)
    return device


@router.put("/mikrotiks/{device_id}", response_model=MikrotikOut)
async def update_mikrotik(device_id: int, body: MikrotikUpdate, db: AsyncSession = Depends(get_db)):
    device = await db.get(MikrotikDevice, device_id)
    if device is None:
        raise HTTPException(status_code=404, detail="Mikrotik not found")
    for field, value in body.model_dump(exclude_unset=True).items():
        setattr(device, field, value)
    await db.commit()
    await db.refresh(device)
    return device


@router.delete("/mikrotiks/{device_id}", status_code=204)
async def delete_mikrotik(device_id: int, db: AsyncSession = Depends(get_db)):
    device = await db.get(MikrotikDevice, device_id)
    if device is None:
        raise HTTPException(status_code=404, detail="Mikrotik not found")
    await db.delete(device)
    await db.commit()


@router.post("/mikrotiks/{device_id}/test", response_model=TestResult)
async def test_mikrotik(device_id: int, db: AsyncSession = Depends(get_db)):
    try:
        message = await collector.test_mikrotik(db, device_id)
        return TestResult(success=True, message=message)
    except Exception as exc:
        return TestResult(success=False, message=str(exc))


@router.post("/mikrotiks/{device_id}/scan", response_model=ScanResult)
async def scan_mikrotik(device_id: int, db: AsyncSession = Depends(get_db)):
    try:
        log = await collector.scan_mikrotik(db, device_id)
        return ScanResult(success=log.status.value == "success", message=log.message, log_id=log.id)
    except Exception as exc:
        return ScanResult(success=False, message=str(exc))