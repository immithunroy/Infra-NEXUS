from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from ..database import get_db
from ..models import Binding, MacEntry, MikrotikDevice, OLTDevice, Onu, User
from ..schemas import ArpEntryOut, BindingOut, MacEntryOut
from ..security import get_current_user
from ..services.mac_binding import run_bindings

router = APIRouter(prefix="/api/bindings", tags=["bindings"], dependencies=[Depends(get_current_user)])


@router.post("/run")
async def trigger_bindings(db: AsyncSession = Depends(get_db)):
    summary = await run_bindings(db)
    return summary


@router.get("", response_model=list[BindingOut])
async def list_bindings(
    bound: bool | None = None,
    db: AsyncSession = Depends(get_db),
):
    q = select(Binding).order_by(Binding.mac)
    if bound is not None:
        q = q.where(Binding.bound.is_(bound))
    rows = (await db.execute(q)).scalars().all()

    olt_names = {d.id: d.name for d in (await db.execute(select(OLTDevice))).scalars()}
    mkt_names = {d.id: d.name for d in (await db.execute(select(MikrotikDevice))).scalars()}
    onu_names = {o.id: (o.name or o.pon_port) for o in (await db.execute(select(Onu))).scalars()}

    out = []
    for b in rows:
        out.append(
            BindingOut(
                mac=b.mac,
                olt_id=b.olt_id,
                olt_name=olt_names.get(b.olt_id, ""),
                olt_port=b.olt_port,
                mikrotik_id=b.mikrotik_id,
                mikrotik_name=mkt_names.get(b.mikrotik_id or -1, ""),
                mikrotik_ip=b.mikrotik_ip,
                mikrotik_interface=b.mikrotik_interface,
                onu_id=b.onu_id,
                onu_name=onu_names.get(b.onu_id or -1, ""),
                bound=b.bound,
                last_checked=b.last_checked,
            )
        )
    return out


@router.get("/olts", response_model=list[MacEntryOut])
async def list_olt_macs(db: AsyncSession = Depends(get_db)):
    rows = (await db.execute(select(MacEntry).order_by(MacEntry.mac))).scalars().all()
    names = {d.id: d.name for d in (await db.execute(select(OLTDevice))).scalars()}
    return [
        MacEntryOut(
            mac=e.mac,
            port=e.port,
            vlan=e.vlan,
            last_seen=e.last_seen,
            olt_id=e.olt_id,
            olt_name=names.get(e.olt_id, ""),
        )
        for e in rows
    ]


@router.get("/mikrotik", response_model=list[ArpEntryOut])
async def list_mikrotik_macs(db: AsyncSession = Depends(get_db)):
    from ..models import ArpEntry

    rows = (await db.execute(select(ArpEntry))).scalars().all()
    names = {d.id: d.name for d in (await db.execute(select(MikrotikDevice))).scalars()}
    return [
        ArpEntryOut(
            mac=e.mac,
            ip=e.ip,
            interface=e.interface,
            last_seen=e.last_seen,
            device_id=e.device_id,
            device_name=names.get(e.device_id, ""),
        )
        for e in rows
    ]