"""Mikrotik RouterOS driver using the RouterOS API (librouteros).

Collects the DHCP lease / ARP tables so that MAC addresses learned on the
OLT can be matched against the customer's IP and RouterOS interface.
"""
from __future__ import annotations

import asyncio
from dataclasses import dataclass

from librouteros import connect

from ..models import MikrotikDevice
from ..utils.mac import normalize_mac
from .base import DriverError


@dataclass
class ArpInfo:
    mac: str
    ip: str
    interface: str
    hostname: str = ""


class MikrotikDriver:
    def __init__(self, device: MikrotikDevice):
        self.device = device

    def _connect(self):
        kwargs = {
            "host": self.device.ip,
            "username": self.device.username,
            "password": self.device.password,
            "port": self.device.api_port,
            "ssl": self.device.use_ssl,
            "timeout": 15,
        }
        try:
            kwargs["login_method"] = "routeros" if self.device.routeros_version >= 7 else "legacy"
        except TypeError:
            pass
        try:
            return connect(**kwargs)
        except TypeError:
            kwargs.pop("login_method", None)
            return connect(**kwargs)

    def _collect(self) -> tuple[list[dict], list[dict]]:
        api = self._connect()
        try:
            arp = list(api("/ip/arp/print"))
            leases = list(api("/ip/dhcp-server/lease/print"))
        finally:
            try:
                api.close()
            except Exception:
                pass
        return arp, leases

    async def test(self) -> str:
        try:
            arp, leases = await asyncio.to_thread(self._collect)
            return f"RouterOS OK ({len(arp)} ARP, {len(leases)} leases)"
        except Exception as exc:
            raise DriverError(f"Mikrotik connection failed: {exc}") from exc

    async def get_arp(self) -> list[ArpInfo]:
        try:
            arp, leases = await asyncio.to_thread(self._collect)
        except Exception as exc:
            raise DriverError(f"Mikrotik collection failed: {exc}") from exc

        by_mac: dict[str, ArpInfo] = {}
        for row in leases:
            mac = normalize_mac(row.get("mac-address", ""))
            if not mac:
                continue
            by_mac[mac] = ArpInfo(
                mac=mac,
                ip=row.get("address", ""),
                interface=row.get("server", ""),
                hostname=row.get("host-name", ""),
            )
        for row in arp:
            mac = normalize_mac(row.get("mac-address", ""))
            if not mac:
                continue
            if mac in by_mac:
                continue
            by_mac[mac] = ArpInfo(
                mac=mac,
                ip=row.get("address", ""),
                interface=row.get("interface", ""),
            )
        return list(by_mac.values())