"""SNMP helpers built on pysnmp 7.x (async hlapi).

Uses the native asyncio SNMP engine so walks integrate with the FastAPI
event loop without blocking it.
"""
from __future__ import annotations

from pysnmp.hlapi.asyncio import (
    CommunityData,
    ContextData,
    ObjectIdentity,
    ObjectType,
    SnmpEngine,
    UdpTransportTarget,
    next_cmd,
)

from .base import DriverError


def _value_str(value) -> str:
    try:
        return value.prettyPrint()
    except Exception:
        return str(value)


async def snmp_walk(
    host: str, community: str, oid: str, port: int = 161, timeout: float = 5.0
) -> list[tuple[str, str]]:
    results: list[tuple[str, str]] = []
    engine = SnmpEngine()
    iterator = next_cmd(
        engine,
        CommunityData(community, mpModel=1),
        UdpTransportTarget((host, port), timeout=timeout, retries=1),
        ContextData(),
        ObjectType(ObjectIdentity(oid)),
        lexicographicMode=False,
    )
    async for error_indication, error_status, error_index, var_binds in iterator:
        if error_indication:
            raise DriverError(f"SNMP error: {error_indication}")
        if error_status:
            raise DriverError(
                f"SNMP error: {error_status.prettyPrint()} at {error_index and var_binds[int(error_index) - 1][0]}"
            )
        for name, value in var_binds:
            results.append((str(name), _value_str(value)))
    return results


async def snmp_get(
    host: str, community: str, oid: str, port: int = 161, timeout: float = 5.0
) -> str | None:
    results = await snmp_walk(host, community, oid, port, timeout)
    if results:
        return results[0][1]
    return None