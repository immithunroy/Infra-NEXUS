"""BDCOM OLT driver (P3310 / P3608 family).

Supports three access methods:
  * telnet  - BDCOM CLI over Telnet (our dependency-free client)
  * ssh     - BDCOM CLI over SSH (asyncssh)
  * snmp    - GPON MIB walks (enterprises.3320) via pysnmp

The CLI path is preferred for MAC collection because `show mac
address-table` carries the PON port the MAC was learned on.
"""
from __future__ import annotations

import asyncio
import re
import time

import asyncssh

from ..config import get_settings
from ..models import OLTDevice
from ..utils.mac import find_mac, normalize_mac
from ..utils.telnet import TelnetClient, TelnetError
from .base import BaseDriver, DriverError, MacInfo, OnuInfo
from .snmp import snmp_walk

# GPON MIB (1.3.6.1.4.1.3320.10.x)
GPON_ONU_STATUS_OID = "1.3.6.1.4.1.3320.10.3.3.1.4"
GPON_ONU_RX_OID = "1.3.6.1.4.1.3320.10.3.4.1.2"
GPON_ONU_TX_OID = "1.3.6.1.4.1.3320.10.3.4.1.3"

ONU_STATUS_MAP = {"0": "inactive", "1": "inactive", "2": "offline", "3": "active"}

_PORT_RE = re.compile(
    r"(?i)(?:gpon|epon)\s*(\d+/\d+):(\d+)"
)
_PON_RE = re.compile(r"(?i)\bgpon\s*(\d+/\d+)")
_SN_RE = re.compile(r"\b([A-Z0-9]{8,16})\b")
_STATUS_RE = re.compile(
    r"(?i)\b(active|inactive|offline|deregistered|registered|authenticated|auth-fail|authorized)\b"
)
_LLID_RE = re.compile(r"llid\s*[:=]?\s*(\d+)", re.I)

# optical diagnosis row: IntfName  Temp Volt Bias Rx Tx
_OPTICAL_RE = re.compile(
    r"(?i)(?:gpon|epon)\s*(\d+/\d+):(\d+)\s+"
    r"([-\d.]++|--)\s+([-\d.]++|--)\s+([-\d.]++|--)\s+([-\d.]++|--)\s+([-\d.]++|--)"
)


def _num(v: str) -> float | None:
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


class BdcomCliDriver(BaseDriver):
    def __init__(self, device: OLTDevice):
        self.device = device
        self.method = device.access_method.value
        self.timeout = 15.0
        self._telnet: TelnetClient | None = None
        self._ssh: asyncssh.SSHClientConnection | None = None
        self._reader = None
        self._writer = None
        self.prompt_line: str = ""

    # -------------------------------------------------------------- connect
    async def _read_char(self) -> bytes:
        if self._telnet is not None:
            return await self._telnet.read_byte()
        if self._reader is not None:
            chunk = await self._reader.read(1)
            if not chunk:
                raise TelnetError("SSH session closed by remote host")
            return chunk.encode("utf-8", errors="replace")
        raise DriverError("Not connected")

    async def _sendline(self, data: str) -> None:
        if self._telnet is not None:
            await self._telnet.sendline(data)
        elif self._writer is not None:
            self._writer.write(data + "\r")
            await self._writer.drain()
        else:
            raise DriverError("Not connected")

    async def _expect(self, patterns: list[str], timeout: float | None = None) -> str:
        timeout = timeout or self.timeout
        buf = ""
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            try:
                c = (await self._read_char()).decode("utf-8", errors="replace")
            except asyncio.TimeoutError:
                continue
            except TelnetError:
                raise
            buf += c
            for pat in patterns:
                if pat in buf:
                    return buf
        raise TelnetError(f"Timeout waiting for {patterns!r}, received: {buf[-200:]!r}")

    async def _read_until_prompt(self, timeout: float | None = None) -> str:
        timeout = timeout or self.timeout
        buf = ""
        deadline = time.monotonic() + timeout
        prompt = self.prompt_line
        while time.monotonic() < deadline:
            try:
                c = (await self._read_char()).decode("utf-8", errors="replace")
            except asyncio.TimeoutError:
                continue
            except TelnetError:
                break
            buf += c
            lower = buf.lower()
            if "--more--" in lower or "press any key" in lower:
                await self._sendline(" ")
                continue
            if prompt and len(buf) > len(prompt) and buf.endswith(prompt):
                return buf
        return buf

    def _detect_prompt(self, text: str) -> None:
        for line in reversed(text.splitlines()):
            s = line.strip()
            if s and (s.endswith(">") or s.endswith("#") or s.endswith("$")):
                self.prompt_line = s
                return
        raise TelnetError(f"Could not detect device prompt in: {text[-300:]!r}")

    async def connect(self) -> None:
        try:
            if self.method == "telnet":
                self._telnet = TelnetClient(self.device.ip, self.device.port, self.timeout)
                await self._telnet.connect()
            else:  # ssh
                self._ssh = await asyncio.wait_for(
                    asyncssh.connect(
                        self.device.ip,
                        port=self.device.port,
                        username=self.device.username,
                        password=self.device.password,
                        known_hosts=None,
                        client_keys=None,
                    ),
                    timeout=self.timeout,
                )
                self._reader, self._writer = await self._ssh.open_session()
        except (OSError, asyncio.TimeoutError, asyncssh.Error) as exc:
            raise DriverError(f"Connection to {self.device.ip} failed: {exc}") from exc
        await self._login()

    async def _login(self) -> None:
        try:
            if self.method == "telnet":
                await self._expect(["Username:", "login:"], timeout=10)
                await self._sendline(self.device.username)
                await self._expect(["Password:", "password:"], timeout=10)
                await self._sendline(self.device.password)
            out = await self._expect([">", "#", "$", "Username:", "Password:"], timeout=12)
            if "Username:" in out or "Password:" in out:
                raise DriverError("Login failed (bad username or password)")
            self._detect_prompt(out)
        except TelnetError as exc:
            raise DriverError(f"Login to {self.device.ip} failed: {exc}") from exc

        if self.prompt_line.endswith(">") and self.device.enable_password:
            await self._sendline("enable")
            try:
                out = await self._expect(["Password:", "#"], timeout=8)
            except TelnetError:
                return
            if "Password:" in out:
                await self._sendline(self.device.enable_password)
                out = await self._expect(["#"], timeout=8)
            try:
                self._detect_prompt(out)
            except TelnetError:
                pass

        for cmd in ("terminal length 0", "terminal paging disable"):
            try:
                await self._exec(cmd, timeout=6)
            except Exception:
                pass

    async def _exec(self, cmd: str, timeout: float | None = None) -> str:
        await self._sendline(cmd)
        out = await self._read_until_prompt(timeout)
        self._detect_prompt(out)
        return out

    def close(self) -> None:
        if self._telnet is not None:
            self._telnet.close()
            self._telnet = None
        if self._ssh is not None:
            try:
                self._ssh.close()
            except Exception:
                pass
            self._ssh = None
        self._reader = None
        self._writer = None

    # ------------------------------------------------------------ interface
    async def test(self) -> str:
        try:
            await self.connect()
            version = await self._exec("show version", timeout=12)
            self.close()
            return f"Connected. {version.strip().splitlines()[0] if version.strip() else 'OK'}"
        except (DriverError, TelnetError) as exc:
            self.close()
            raise DriverError(str(exc)) from exc

    def _parse_onu_info(self, output: str) -> dict[tuple[str, int], OnuInfo]:
        onus: dict[tuple[str, int], OnuInfo] = {}
        for line in output.splitlines():
            m = _PORT_RE.search(line)
            if not m:
                continue
            pon_port = f"GPON{m.group(1)}:{m.group(2)}" if "gpon" in line.lower() else f"EPON{m.group(1)}:{m.group(2)}"
            pon_base = f"GPON{m.group(1)}" if "gpon" in line.lower() else f"EPON{m.group(1)}"
            onu_id = int(m.group(2))
            info = OnuInfo(pon_port=pon_port, onu_id=onu_id)
            sm = _SN_RE.search(line)
            if sm:
                info.serial = sm.group(1)
            st = _STATUS_RE.search(line)
            if st:
                info.state = st.group(1).lower()
            onus[(pon_base, onu_id)] = info
        return onus

    def _parse_optical(self, output: str) -> dict[tuple[str, int], tuple[float | None, float | None]]:
        result: dict[tuple[str, int], tuple[float | None, float | None]] = {}
        for line in output.splitlines():
            m = _OPTICAL_RE.search(line)
            if not m:
                continue
            pon_base = f"GPON{m.group(1)}" if "gpon" in line.lower() else f"EPON{m.group(1)}"
            onu_id = int(m.group(2))
            rx = _num(m.group(6))
            tx = _num(m.group(7))
            result[(pon_base, onu_id)] = (rx, tx)
        return result

    def _parse_macs(self, output: str) -> list[MacInfo]:
        macs: list[MacInfo] = []
        seen: set[str] = set()
        for line in output.splitlines():
            mac = find_mac(line)
            if not mac or mac in seen:
                continue
            pm = _PORT_RE.search(line)
            port = ""
            if pm:
                prefix = "GPON" if "gpon" in line.lower() else "EPON"
                port = f"{prefix}{pm.group(1)}:{pm.group(2)}"
            else:
                gm = re.search(r"(?i)\b(?:giga|te|xe|ge)\s*\S*?(\d+/\d+)", line)
                if gm:
                    port = gm.group(0).strip()
            vlan = 0
            vm = re.search(r"(?<!\d)(\d{1,4})(?!\d)", line)
            if vm:
                vlan = int(vm.group(1))
            seen.add(mac)
            macs.append(MacInfo(mac=mac, port=port, vlan=vlan))
        return macs

    async def get_onus(self) -> list[OnuInfo]:
        try:
            await self.connect()
        except DriverError:
            raise
        try:
            if self.device.pon_type.lower() == "epon":
                output = await self._exec("show epon onu-information", timeout=15)
            else:
                output = await self._exec("show gpon onu-information", timeout=15)
            onus = self._parse_onu_info(output)

            pon_bases = sorted({k[0] for k in onus})
            for pon in pon_bases:
                if pon.startswith("GPON"):
                    optical = await self._exec(f"show gpon onu-optical-transceiver-diagnosis interface gpON {pon.replace('GPON', '')}", timeout=12)
                else:
                    optical = await self._exec(f"show epon optical-transceiver-diagnosis interface epON {pon.replace('EPON', '')}", timeout=12)
                for (base, onu_id), (rx, tx) in self._parse_optical(optical).items():
                    key = (base, onu_id)
                    if key in onus:
                        onus[key].rx = rx
                        onus[key].tx = tx
            return list(onus.values())
        except TelnetError as exc:
            raise DriverError(f"Failed to collect ONUs: {exc}") from exc
        finally:
            self.close()

    async def get_macs(self) -> list[MacInfo]:
        try:
            await self.connect()
        except DriverError:
            raise
        try:
            for cmd in ("show mac address-table", "show mac-address-table dynamic"):
                try:
                    output = await self._exec(cmd, timeout=20)
                except TelnetError:
                    continue
                macs = self._parse_macs(output)
                if macs:
                    return macs
            return []
        finally:
            self.close()


class BdcomSnmpDriver(BaseDriver):
    """SNMP-only collector for BDCOM GPON OLTs."""

    def __init__(self, device: OLTDevice):
        self.device = device

    @property
    def _target(self) -> tuple[str, str, int]:
        return (self.device.ip, self.device.snmp_community, self.device.snmp_port)

    async def test(self) -> str:
        host, community, port = self._target
        try:
            results = await snmp_walk(host, community, GPON_ONU_STATUS_OID, port)
            return f"SNMP OK ({len(results)} ONUs)"
        except DriverError as exc:
            raise DriverError(f"SNMP test failed: {exc}") from exc

    async def get_onus(self) -> list[OnuInfo]:
        host, community, port = self._target
        status_rows = await snmp_walk(host, community, GPON_ONU_STATUS_OID, port)
        rx_rows = await snmp_walk(host, community, GPON_ONU_RX_OID, port)
        tx_rows = await snmp_walk(host, community, GPON_ONU_TX_OID, port)

        def _index(oid: str) -> tuple[int, int]:
            parts = oid.split(".")
            tail = [int(p) for p in parts[-4:]] if len(parts) >= 4 else []
            if len(tail) == 4:
                return (tail[2], tail[3])  # (pon port, onu id)
            return (0, 0)

        status: dict[tuple[int, int], str] = {}
        for oid, value in status_rows:
            port_no, onu_id = _index(oid)
            status[(port_no, onu_id)] = ONU_STATUS_MAP.get(value, "unknown")

        rx_power = {(_index(oid)[1]): _num(v) for oid, v in rx_rows}
        tx_power = {(_index(oid)[1]): _num(v) for oid, v in tx_rows}

        onus: list[OnuInfo] = []
        for (port_no, onu_id), state in status.items():
            # DBm units are 0.1 dBm in this MIB
            rx = rx_power.get(onu_id)
            tx = tx_power.get(onu_id)
            if rx is not None:
                rx = rx / 10.0
            if tx is not None:
                tx = tx / 10.0
            onus.append(
                OnuInfo(
                    pon_port=f"GPON0/{port_no}:{onu_id}",
                    onu_id=onu_id,
                    state=state,
                    rx=rx,
                    tx=tx,
                )
            )
        return onus

    async def get_macs(self) -> list[MacInfo]:
        # Not reliably exposed for all firmware versions; collector falls back
        # to an empty list and the CLI path is preferred anyway.
        return []


def build_driver(device: OLTDevice) -> BaseDriver:
    if device.access_method.value == "snmp":
        return BdcomSnmpDriver(device)
    return BdcomCliDriver(device)