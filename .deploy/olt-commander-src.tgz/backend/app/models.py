import enum
from datetime import datetime

from sqlalchemy import (
    BigInteger,
    Boolean,
    DateTime,
    Enum,
    ForeignKey,
    Integer,
    String,
    Text,
    UniqueConstraint,
    func,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .database import Base

# BigInteger primary keys keep a huge id range on Postgres but degrade to a
# normal INTEGER on SQLite (so the app also works for local testing).
BigId = BigInteger().with_variant(Integer, "sqlite")


class OnuSource(str, enum.Enum):
    manual = "manual"
    auto = "auto"


class OnuState(str, enum.Enum):
    active = "active"
    inactive = "inactive"
    offline = "offline"
    unknown = "unknown"


class AccessMethod(str, enum.Enum):
    telnet = "telnet"
    ssh = "ssh"
    snmp = "snmp"


class ScanType(str, enum.Enum):
    olt = "olt"
    mikrotik = "mikrotik"
    bind = "bind"


class ScanStatus(str, enum.Enum):
    running = "running"
    success = "success"
    failed = "failed"


class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(primary_key=True)
    username: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    password_hash: Mapped[str] = mapped_column(String(256))
    is_admin: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())


class OLTDevice(Base):
    __tablename__ = "olt_devices"

    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(128), index=True)
    ip: Mapped[str] = mapped_column(String(64))
    vendor: Mapped[str] = mapped_column(String(32), default="bdcom")
    pon_type: Mapped[str] = mapped_column(String(8), default="gpon")  # gpon | epon
    access_method: Mapped[AccessMethod] = mapped_column(
        Enum(AccessMethod), default=AccessMethod.telnet
    )
    port: Mapped[int] = mapped_column(Integer, default=23)
    username: Mapped[str] = mapped_column(String(128), default="")
    password: Mapped[str] = mapped_column(String(256), default="")
    enable_password: Mapped[str] = mapped_column(String(256), default="")
    snmp_community: Mapped[str] = mapped_column(String(64), default="public")
    snmp_version: Mapped[str] = mapped_column(String(8), default="2c")
    snmp_port: Mapped[int] = mapped_column(Integer, default=161)
    enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    status: Mapped[str] = mapped_column(String(32), default="unknown")  # reachable | unreachable | unknown
    last_scan_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    last_message: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    onus: Mapped[list["Onu"]] = relationship(back_populates="olt", cascade="all, delete-orphan")


class MikrotikDevice(Base):
    __tablename__ = "mikrotik_devices"

    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(128), index=True)
    ip: Mapped[str] = mapped_column(String(64))
    api_port: Mapped[int] = mapped_column(Integer, default=8728)
    use_ssl: Mapped[bool] = mapped_column(Boolean, default=False)
    routeros_version: Mapped[int] = mapped_column(Integer, default=6)  # 6 | 7
    username: Mapped[str] = mapped_column(String(128), default="")
    password: Mapped[str] = mapped_column(String(256), default="")
    enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    status: Mapped[str] = mapped_column(String(32), default="unknown")
    last_scan_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    last_message: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())


class Onu(Base):
    __tablename__ = "onus"

    id: Mapped[int] = mapped_column(primary_key=True)
    olt_id: Mapped[int] = mapped_column(ForeignKey("olt_devices.id", ondelete="CASCADE"), index=True)
    source: Mapped[OnuSource] = mapped_column(Enum(OnuSource), default=OnuSource.manual)
    state: Mapped[OnuState] = mapped_column(Enum(OnuState), default=OnuState.unknown)

    name: Mapped[str] = mapped_column(String(256), default="")
    serial: Mapped[str] = mapped_column(String(64), default="", index=True)
    mac: Mapped[str] = mapped_column(String(32), default="")
    pon_port: Mapped[str] = mapped_column(String(32), default="", index=True)  # e.g. GPON0/1:5
    onu_id: Mapped[int] = mapped_column(Integer, default=0)
    vlan: Mapped[int] = mapped_column(Integer, default=0)

    rx_power: Mapped[float | None] = mapped_column(nullable=True)
    tx_power: Mapped[float | None] = mapped_column(nullable=True)

    last_mac: Mapped[str] = mapped_column(String(32), default="")
    mikrotik_ip: Mapped[str] = mapped_column(String(64), default="")
    bound: Mapped[bool] = mapped_column(Boolean, default=False)

    note: Mapped[str] = mapped_column(Text, default="")
    last_seen: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )

    olt: Mapped["OLTDevice"] = relationship(back_populates="onus")

    __table_args__ = (
        UniqueConstraint("olt_id", "pon_port", "onu_id", name="uq_olt_pon_onu"),
    )


class MacEntry(Base):
    __tablename__ = "mac_entries"

    id: Mapped[int] = mapped_column(BigId, primary_key=True)
    olt_id: Mapped[int] = mapped_column(ForeignKey("olt_devices.id", ondelete="CASCADE"), index=True)
    mac: Mapped[str] = mapped_column(String(32), index=True)
    port: Mapped[str] = mapped_column(String(32), default="")
    vlan: Mapped[int] = mapped_column(Integer, default=0)
    first_seen: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    last_seen: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    __table_args__ = (
        UniqueConstraint("olt_id", "mac", name="uq_olt_mac"),
    )


class ArpEntry(Base):
    __tablename__ = "arp_entries"

    id: Mapped[int] = mapped_column(BigId, primary_key=True)
    device_id: Mapped[int] = mapped_column(ForeignKey("mikrotik_devices.id", ondelete="CASCADE"), index=True)
    mac: Mapped[str] = mapped_column(String(32), index=True)
    ip: Mapped[str] = mapped_column(String(64), default="")
    interface: Mapped[str] = mapped_column(String(64), default="")
    first_seen: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    last_seen: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    __table_args__ = (
        UniqueConstraint("device_id", "mac", name="uq_device_mac"),
    )


class Binding(Base):
    __tablename__ = "bindings"

    id: Mapped[int] = mapped_column(BigId, primary_key=True)
    mac: Mapped[str] = mapped_column(String(32), index=True)
    olt_id: Mapped[int] = mapped_column(ForeignKey("olt_devices.id", ondelete="CASCADE"), index=True)
    olt_port: Mapped[str] = mapped_column(String(32), default="")
    mikrotik_id: Mapped[int] = mapped_column(
        ForeignKey("mikrotik_devices.id", ondelete="CASCADE"), index=True, nullable=True
    )
    mikrotik_ip: Mapped[str] = mapped_column(String(64), default="")
    mikrotik_interface: Mapped[str] = mapped_column(String(64), default="")
    onu_id: Mapped[int | None] = mapped_column(ForeignKey("onus.id", ondelete="SET NULL"), nullable=True)
    bound: Mapped[bool] = mapped_column(Boolean, default=False)
    last_checked: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    __table_args__ = (
        UniqueConstraint("mac", "olt_id", name="uq_mac_olt"),
    )


class ScanLog(Base):
    __tablename__ = "scan_logs"

    id: Mapped[int] = mapped_column(BigId, primary_key=True)
    scan_type: Mapped[ScanType] = mapped_column(Enum(ScanType))
    device_id: Mapped[int] = mapped_column(Integer, default=0)
    device_name: Mapped[str] = mapped_column(String(128), default="")
    status: Mapped[ScanStatus] = mapped_column(Enum(ScanStatus), default=ScanStatus.running)
    message: Mapped[str] = mapped_column(Text, default="")
    started_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    finished_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)