"""MAC binding engine.

Compares MAC addresses learned on OLT PON ports against the ARP / DHCP
lease table collected from Mikrotik routers and records who is bound to
what. Writing a binding only ever touches our own database - it never
changes the Mikrotik or the OLT.
"""
from __future__ import annotations

import logging
from datetime import datetime

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from ..models import ArpEntry, Binding, MacEntry, MikrotikDevice, OLTDevice, Onu

logger = logging.getLogger("olt_commander.binding")


async def _get_binding(session: AsyncSession, mac: str, olt_id: int) -> Binding:
    res = await session.execute(select(Binding).where(Binding.mac == mac, Binding.olt_id == olt_id))
    binding = res.scalar_one_or_none()
    if binding is None:
        binding = Binding(mac=mac, olt_id=olt_id)
        session.add(binding)
    return binding


async def _find_onu_id(session: AsyncSession, olt_id: int, mac: str, port: str) -> int | None:
    if mac:
        res = await session.execute(select(Onu.id).where(Onu.olt_id == olt_id, Onu.last_mac == mac))
        onu_id = res.scalar_one_or_none()
        if onu_id is not None:
            return onu_id
    if port:
        res = await session.execute(
            select(Onu.id).where(Onu.olt_id == olt_id, Onu.pon_port == port.upper())
        )
        onu_id = res.scalars().first()
        if onu_id is not None:
            return onu_id
    return None


async def run_bindings(session: AsyncSession) -> dict:
    """Match OLT MACs against Mikrotik ARP entries and persist Binding rows.

    Returns a summary dict of the operation.
    """
    now = datetime.utcnow()

    mac_rows = (
        await session.execute(select(MacEntry, OLTDevice).join(OLTDevice, OLTDevice.id == MacEntry.olt_id))
    ).all()
    arp_rows = (
        await session.execute(
            select(ArpEntry, MikrotikDevice).join(MikrotikDevice, MikrotikDevice.id == ArpEntry.device_id)
        )
    ).all()

    arp_by_mac: dict[str, tuple[ArpEntry, MikrotikDevice]] = {}
    for arp, mkt in arp_rows:
        if arp.mac not in arp_by_mac:
            arp_by_mac[arp.mac] = (arp, mkt)

    matched = 0
    unmatched = 0

    for mac_entry, olt in mac_rows:
        hit = arp_by_mac.get(mac_entry.mac)
        if hit is not None:
            arp, mkt = hit
            matched += 1
        else:
            arp, mkt = None, None

        binding = await _get_binding(session, mac_entry.mac, olt.id)
        binding.mac = mac_entry.mac
        binding.olt_id = olt.id
        binding.olt_port = mac_entry.port
        binding.mikrotik_id = mkt.id if mkt else None
        binding.mikrotik_ip = arp.ip if arp else ""
        binding.mikrotik_interface = arp.interface if arp else ""
        binding.bound = hit is not None
        binding.onu_id = await _find_onu_id(session, olt.id, mac_entry.mac, mac_entry.port)
        binding.last_checked = now

        # Mirror the result onto the linked ONU record (if any).
        if binding.onu_id is not None:
            onu = await session.get(Onu, binding.onu_id)
            if onu is not None:
                onu.last_mac = mac_entry.mac
                onu.bound = hit is not None
                onu.mikrotik_ip = arp.ip if arp else ""

    # Any ONU whose last MAC no longer matches a bound MAC is unbound now.
    bound_macs = {e.mac for e, _ in mac_rows if e.mac in arp_by_mac}
    onus = (await session.execute(select(Onu))).scalars().all()
    for onu in onus:
        if onu.last_mac and onu.last_mac not in bound_macs:
            onu.bound = False
            onu.mikrotik_ip = ""

    await session.commit()
    summary = {
        "matched": matched,
        "unmatched": unmatched,
        "total_macs": len(mac_rows),
        "total_arp": len(arp_rows),
    }
    logger.info("Binding run finished: %s", summary)
    return summary