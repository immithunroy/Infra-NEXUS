"""Collection service.

Drives OLT and Mikrotik scans, persists ONUs / MAC tables / ARP tables and
keeps device health status up to date.
"""
from __future__ import annotations

import logging
from datetime import datetime, timedelta

from sqlalchemy import delete, select
from sqlalchemy.ext.asyncio import AsyncSession

from ..drivers.bdcom import build_driver
from ..drivers.base import DriverError
from ..drivers.mikrotik import MikrotikDriver
from ..models import (
    ArpEntry,
    MacEntry,
    MikrotikDevice,
    OLTDevice,
    Onu,
    OnuSource,
    OnuState,
    ScanLog,
    ScanStatus,
    ScanType,
)

logger = logging.getLogger("olt_commander.collector")


def _normalize_port(port: str) -> str:
    """Return a canonical upper-case PON/ONU port token for matching."""
    if not port:
        return ""
    return port.upper().replace(" ", "")


async def _start_log(session: AsyncSession, scan_type: ScanType, device_id: int, device_name: str) -> ScanLog:
    log = ScanLog(scan_type=scan_type, device_id=device_id, device_name=device_name)
    session.add(log)
    await session.commit()
    await session.refresh(log)
    return log


async def _finish_log(session: AsyncSession, log: ScanLog, status: ScanStatus, message: str) -> None:
    log.status = status
    log.message = message[:4000]
    log.finished_at = datetime.utcnow()
    await session.commit()


def _map_state(state: str) -> OnuState:
    state = (state or "unknown").lower()
    if "active" in state or "authorized" in state or "registered" in state:
        return OnuState.active
    if "inactive" in state or "deregistered" in state:
        return OnuState.inactive
    if "offline" in state or "auth-fail" in state:
        return OnuState.offline
    return OnuState.unknown


async def _upsert_onu(
    session: AsyncSession,
    olt_id: int,
    pon_port: str,
    onu_id: int,
    serial: str,
    state: OnuState,
    rx: float | None,
    tx: float | None,
) -> Onu:
    key = (_normalize_port(pon_port), onu_id)
    res = await session.execute(
        select(Onu).where(Onu.olt_id == olt_id, Onu.pon_port == key[0], Onu.onu_id == key[1])
    )
    onu = res.scalar_one_or_none()
    if onu is None and serial:
        res = await session.execute(select(Onu).where(Onu.olt_id == olt_id, Onu.serial == serial))
        onu = res.scalar_one_or_none()
    if onu is None:
        onu = Onu(
            olt_id=olt_id,
            source=OnuSource.auto,
            pon_port=key[0],
            onu_id=key[1],
            serial=serial or "",
        )
        session.add(onu)
    onu.state = state
    onu.serial = serial or onu.serial
    onu.rx_power = rx
    onu.tx_power = tx
    onu.last_seen = datetime.utcnow()
    await session.flush()
    return onu


async def _upsert_mac(session: AsyncSession, olt_id: int, mac: str, port: str, vlan: int) -> None:
    res = await session.execute(select(MacEntry).where(MacEntry.olt_id == olt_id, MacEntry.mac == mac))
    entry = res.scalar_one_or_none()
    now = datetime.utcnow()
    if entry is None:
        session.add(MacEntry(olt_id=olt_id, mac=mac, port=_normalize_port(port), vlan=vlan, last_seen=now))
    else:
        entry.port = _normalize_port(port) or entry.port
        entry.vlan = vlan or entry.vlan
        entry.last_seen = now


async def _link_mac_to_onu(session: AsyncSession, olt_id: int, mac: str, port: str) -> None:
    """Attach the learned MAC to the ONU sitting on that PON port."""
    port = _normalize_port(port)
    if not port:
        return
    res = await session.execute(select(Onu).where(Onu.olt_id == olt_id, Onu.pon_port == port))
    onu = res.scalars().first()
    if onu is not None:
        onu.last_mac = mac


async def scan_olt(session: AsyncSession, olt_id: int) -> ScanLog:
    device = await session.get(OLTDevice, olt_id)
    if device is None:
        raise ValueError(f"OLT device {olt_id} not found")
    log = await _start_log(session, ScanType.olt, olt_id, device.name)
    if not device.enabled:
        await _finish_log(session, log, ScanStatus.failed, "Device disabled")
        return log

    driver = build_driver(device)
    try:
        onus = await driver.get_onus()
        macs = await driver.get_macs()
    except DriverError as exc:
        device.status = "unreachable"
        device.last_message = str(exc)[:1000]
        device.last_scan_at = datetime.utcnow()
        await _finish_log(session, log, ScanStatus.failed, str(exc))
        await session.commit()
        return log

    seen_macs: set[str] = set()
    for onu_info in onus:
        await _upsert_onu(
            session,
            olt_id,
            onu_info.pon_port,
            onu_info.onu_id,
            onu_info.serial,
            _map_state(onu_info.state),
            onu_info.rx,
            onu_info.tx,
        )
    for mac_info in macs:
        seen_macs.add(mac_info.mac)
        await _upsert_mac(session, olt_id, mac_info.mac, mac_info.port, mac_info.vlan)
        await _link_mac_to_onu(session, olt_id, mac_info.mac, mac_info.port)

    if macs:
        # Purge MACs no longer present on the device (client disconnected).
        await session.execute(
            delete(MacEntry).where(MacEntry.olt_id == olt_id, MacEntry.mac.notin_(seen_macs))
        )

    await session.flush()
    device.status = "reachable"
    device.last_scan_at = datetime.utcnow()
    device.last_message = f"Collected {len(onus)} ONUs, {len(macs)} MACs"
    await _finish_log(session, log, ScanStatus.success, device.last_message)
    await session.commit()
    return log


async def scan_mikrotik(session: AsyncSession, device_id: int) -> ScanLog:
    device = await session.get(MikrotikDevice, device_id)
    if device is None:
        raise ValueError(f"Mikrotik device {device_id} not found")
    log = await _start_log(session, ScanType.mikrotik, device_id, device.name)
    if not device.enabled:
        await _finish_log(session, log, ScanStatus.failed, "Device disabled")
        return log

    driver = MikrotikDriver(device)
    try:
        entries = await driver.get_arp()
    except DriverError as exc:
        device.status = "unreachable"
        device.last_message = str(exc)[:1000]
        device.last_scan_at = datetime.utcnow()
        await _finish_log(session, log, ScanStatus.failed, str(exc))
        await session.commit()
        return log

    seen_macs: set[str] = set()
    for e in entries:
        seen_macs.add(e.mac)
        res = await session.execute(
            select(ArpEntry).where(ArpEntry.device_id == device_id, ArpEntry.mac == e.mac)
        )
        entry = res.scalar_one_or_none()
        now = datetime.utcnow()
        if entry is None:
            session.add(
                ArpEntry(device_id=device_id, mac=e.mac, ip=e.ip, interface=e.interface, last_seen=now)
            )
        else:
            entry.ip = e.ip or entry.ip
            entry.interface = e.interface or entry.interface
            entry.last_seen = now

    if entries:
        await session.execute(
            delete(ArpEntry).where(ArpEntry.device_id == device_id, ArpEntry.mac.notin_(seen_macs))
        )

    await session.flush()
    device.status = "reachable"
    device.last_scan_at = datetime.utcnow()
    device.last_message = f"Collected {len(entries)} MAC/IP entries"
    await _finish_log(session, log, ScanStatus.success, device.last_message)
    await session.commit()
    return log


async def test_olt(session: AsyncSession, olt_id: int) -> str:
    device = await session.get(OLTDevice, olt_id)
    if device is None:
        raise ValueError(f"OLT device {olt_id} not found")
    driver = build_driver(device)
    try:
        message = await driver.test()
    except DriverError as exc:
        device.status = "unreachable"
        device.last_message = str(exc)[:1000]
        await session.commit()
        raise
    device.status = "reachable"
    device.last_message = message[:1000]
    await session.commit()
    return message


async def test_mikrotik(session: AsyncSession, device_id: int) -> str:
    device = await session.get(MikrotikDevice, device_id)
    if device is None:
        raise ValueError(f"Mikrotik device {device_id} not found")
    driver = MikrotikDriver(device)
    try:
        message = await driver.test()
    except DriverError as exc:
        device.status = "unreachable"
        device.last_message = str(exc)[:1000]
        await session.commit()
        raise
    device.status = "reachable"
    device.last_message = message[:1000]
    await session.commit()
    return message