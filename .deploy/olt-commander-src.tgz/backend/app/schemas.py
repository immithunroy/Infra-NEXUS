from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


class LoginRequest(BaseModel):
    username: str
    password: str


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"


class UserOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    username: str
    is_admin: bool


class OLTDeviceBase(BaseModel):
    name: str
    ip: str
    vendor: str = "bdcom"
    pon_type: str = "gpon"
    access_method: str = "telnet"
    port: int = 23
    username: str = ""
    password: str = ""
    enable_password: str = ""
    snmp_community: str = "public"
    snmp_version: str = "2c"
    snmp_port: int = 161
    enabled: bool = True


class OLTDeviceCreate(OLTDeviceBase):
    pass


class OLTDeviceUpdate(BaseModel):
    name: str | None = None
    ip: str | None = None
    vendor: str | None = None
    pon_type: str | None = None
    access_method: str | None = None
    port: int | None = None
    username: str | None = None
    password: str | None = None
    enable_password: str | None = None
    snmp_community: str | None = None
    snmp_version: str | None = None
    snmp_port: int | None = None
    enabled: bool | None = None


class OLTDeviceOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    name: str
    ip: str
    vendor: str
    pon_type: str
    access_method: str
    port: int
    username: str
    password: str = ""
    enable_password: str = ""
    snmp_community: str
    snmp_version: str
    snmp_port: int
    enabled: bool
    status: str
    last_scan_at: datetime | None
    last_message: str
    onu_count: int = 0


class MikrotikBase(BaseModel):
    name: str
    ip: str
    api_port: int = 8728
    use_ssl: bool = False
    routeros_version: int = 6
    username: str = ""
    password: str = ""
    enabled: bool = True


class MikrotikCreate(MikrotikBase):
    pass


class MikrotikUpdate(BaseModel):
    name: str | None = None
    ip: str | None = None
    api_port: int | None = None
    use_ssl: bool | None = None
    routeros_version: int | None = None
    username: str | None = None
    password: str | None = None
    enabled: bool | None = None


class MikrotikOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    name: str
    ip: str
    api_port: int
    use_ssl: bool
    routeros_version: int
    username: str
    password: str = ""
    enabled: bool
    status: str
    last_scan_at: datetime | None
    last_message: str


class OnuBase(BaseModel):
    name: str = ""
    serial: str = ""
    mac: str = ""
    pon_port: str = ""
    onu_id: int = 0
    vlan: int = 0
    note: str = ""


class OnuCreate(OnuBase):
    olt_id: int


class OnuUpdate(BaseModel):
    name: str | None = None
    serial: str | None = None
    mac: str | None = None
    pon_port: str | None = None
    onu_id: int | None = None
    vlan: int | None = None
    note: str | None = None


class OnuOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    olt_id: int
    olt_name: str = ""
    source: str
    state: str
    name: str
    serial: str
    mac: str
    pon_port: str
    onu_id: int
    vlan: int
    rx_power: float | None
    tx_power: float | None
    last_mac: str
    mikrotik_ip: str
    bound: bool
    note: str
    last_seen: datetime | None
    created_at: datetime


class TestResult(BaseModel):
    success: bool
    message: str


class ScanResult(BaseModel):
    success: bool
    message: str
    log_id: int | None = None


class MacEntryOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    mac: str
    port: str
    vlan: int
    last_seen: datetime
    olt_id: int
    olt_name: str = ""


class ArpEntryOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    mac: str
    ip: str
    interface: str
    last_seen: datetime
    device_id: int
    device_name: str = ""


class BindingOut(BaseModel):
    mac: str
    olt_id: int
    olt_name: str
    olt_port: str
    mikrotik_id: int | None
    mikrotik_name: str
    mikrotik_ip: str
    mikrotik_interface: str
    onu_id: int | None
    onu_name: str
    bound: bool
    last_checked: datetime


class DashboardSummary(BaseModel):
    olt_count: int
    olt_reachable: int
    mikrotik_count: int
    onu_total: int
    onu_manual: int
    onu_active: int
    onu_inactive: int
    onu_bound: int
    olt_mac_count: int
    arp_mac_count: int
    matched_mac_count: int
    last_scan: datetime | None


class ScanLogOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    scan_type: str
    device_id: int
    device_name: str
    status: str
    message: str
    started_at: datetime
    finished_at: datetime | None


class Message(BaseModel):
    detail: str = Field(default="")