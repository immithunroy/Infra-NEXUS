import { FormEvent, useEffect, useState } from "react";
import { api } from "../api/client";
import { MikrotikDevice, OLTDevice, TestResult } from "../api/types";

type Kind = "olt" | "mikrotik";

interface FormState {
  id?: number;
  kind: Kind;
  name: string;
  ip: string;
  vendor: string;
  pon_type: string;
  access_method: string;
  port: number;
  username: string;
  password: string;
  enable_password: string;
  snmp_community: string;
  api_port: number;
  use_ssl: boolean;
  routeros_version: number;
  enabled: boolean;
}

const emptyForm = (kind: Kind): FormState => ({
  kind,
  name: "",
  ip: "",
  vendor: "bdcom",
  pon_type: "gpon",
  access_method: "telnet",
  port: 23,
  username: "",
  password: "",
  enable_password: "",
  snmp_community: "public",
  api_port: 8728,
  use_ssl: false,
  routeros_version: 6,
  enabled: true,
});

function StatusBadge({ status }: { status: string }) {
  const map: Record<string, string> = {
    reachable: "bg-emerald-100 text-emerald-700",
    unreachable: "bg-red-100 text-red-700",
    unknown: "bg-slate-100 text-slate-600",
  };
  return <span className={`badge ${map[status] || map.unknown}`}>{status}</span>;
}

export default function Devices() {
  const [olts, setOlts] = useState<OLTDevice[]>([]);
  const [mikrotiks, setMikrotiks] = useState<MikrotikDevice[]>([]);
  const [modal, setModal] = useState<FormState | null>(null);
  const [busyId, setBusyId] = useState<string>("");
  const [notice, setNotice] = useState<{ text: string; ok: boolean } | null>(null);

  const load = async () => {
    setOlts(await api.get<OLTDevice[]>("/devices/olts"));
    setMikrotiks(await api.get<MikrotikDevice[]>("/devices/mikrotiks"));
  };

  useEffect(() => {
    load().catch((e) => setNotice({ text: String(e), ok: false }));
  }, []);

  const flash = (text: string, ok = true) => {
    setNotice({ text, ok });
    setTimeout(() => setNotice(null), 5000);
  };

  const openNew = (kind: Kind) => setModal(emptyForm(kind));
  const openEdit = (kind: Kind, device: OLTDevice | MikrotikDevice) => {
    setModal({
      ...emptyForm(kind),
      id: device.id,
      name: device.name,
      ip: device.ip,
      enabled: device.enabled,
      ...(kind === "olt"
        ? {
            vendor: (device as OLTDevice).vendor,
            pon_type: (device as OLTDevice).pon_type,
            access_method: (device as OLTDevice).access_method,
            port: (device as OLTDevice).port,
            username: (device as OLTDevice).username,
            password: (device as OLTDevice).password,
            enable_password: (device as OLTDevice).enable_password,
            snmp_community: (device as OLTDevice).snmp_community,
          }
        : {
            api_port: (device as MikrotikDevice).api_port,
            use_ssl: (device as MikrotikDevice).use_ssl,
            routeros_version: (device as MikrotikDevice).routeros_version,
            username: (device as MikrotikDevice).username,
            password: (device as MikrotikDevice).password,
          }),
    });
  };

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!modal) return;
    const base = { name: modal.name, ip: modal.ip, enabled: modal.enabled };
    try {
      if (modal.kind === "olt") {
        const body = {
          ...base,
          vendor: modal.vendor,
          pon_type: modal.pon_type,
          access_method: modal.access_method,
          port: modal.port,
          username: modal.username,
          password: modal.password,
          enable_password: modal.enable_password,
          snmp_community: modal.snmp_community,
        };
        if (modal.id) await api.put(`/devices/olts/${modal.id}`, body);
        else await api.post("/devices/olts", body);
      } else {
        const body = {
          ...base,
          api_port: modal.api_port,
          use_ssl: modal.use_ssl,
          routeros_version: modal.routeros_version,
          username: modal.username,
          password: modal.password,
        };
        if (modal.id) await api.put(`/devices/mikrotiks/${modal.id}`, body);
        else await api.post("/devices/mikrotiks", body);
      }
      flash("Device saved");
      setModal(null);
      await load();
    } catch (err) {
      flash(err instanceof Error ? err.message : "Save failed", false);
    }
  };

  const remove = async (kind: Kind, id: number) => {
    if (!confirm("Delete this device? This also removes its collected data.")) return;
    try {
      await api.del(`/devices/${kind === "olt" ? "olts" : "mikrotiks"}/${id}`);
      flash("Device deleted");
      await load();
    } catch (err) {
      flash(err instanceof Error ? err.message : "Delete failed", false);
    }
  };

  const test = async (kind: Kind, id: number) => {
    setBusyId(`test-${kind}-${id}`);
    try {
      const res = await api.post<TestResult>(`/devices/${kind === "olt" ? "olts" : "mikrotiks"}/${id}/test`);
      flash(res.success ? `Test OK: ${res.message}` : `Test failed: ${res.message}`, res.success);
    } catch (err) {
      flash(err instanceof Error ? err.message : "Test failed", false);
    } finally {
      setBusyId("");
      await load();
    }
  };

  const scan = async (kind: Kind, id: number) => {
    setBusyId(`scan-${kind}-${id}`);
    try {
      const res = await api.post<TestResult>(`/devices/${kind === "olt" ? "olts" : "mikrotiks"}/${id}/scan`);
      flash(res.success ? `Scan complete: ${res.message}` : `Scan failed: ${res.message}`, res.success);
    } catch (err) {
      flash(err instanceof Error ? err.message : "Scan failed", false);
    } finally {
      setBusyId("");
      await load();
    }
  };

  return (
    <div className="space-y-8">
      <header className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Devices</h1>
          <p className="text-sm text-slate-500">OLT and Mikrotik servers</p>
        </div>
        <div className="flex gap-2">
          <button className="btn-secondary" onClick={() => openNew("mikrotik")}>+ Mikrotik</button>
          <button className="btn-primary" onClick={() => openNew("olt")}>+ OLT</button>
        </div>
      </header>

      {notice && (
        <div className={`rounded-md px-4 py-2 text-sm ${notice.ok ? "bg-emerald-50 text-emerald-700" : "bg-red-50 text-red-700"}`}>
          {notice.text}
        </div>
      )}

      <section>
        <h2 className="mb-3 text-sm font-semibold uppercase tracking-wide text-slate-500">OLT Devices</h2>
        <div className="card overflow-x-auto">
          <table className="w-full">
            <thead className="border-b border-slate-200 bg-slate-50">
              <tr>
                <th className="th">Name</th>
                <th className="th">IP</th>
                <th className="th">Vendor / PON</th>
                <th className="th">Access</th>
                <th className="th">ONUs</th>
                <th className="th">Status</th>
                <th className="th">Last scan</th>
                <th className="th">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {olts.map((d) => (
                <tr key={d.id} className="hover:bg-slate-50">
                  <td className="td font-medium">{d.name}</td>
                  <td className="td font-mono text-xs">{d.ip}</td>
                  <td className="td">{d.vendor} · {d.pon_type.toUpperCase()}</td>
                  <td className="td">{d.access_method}{d.access_method !== "snmp" ? `:${d.port}` : ""}</td>
                  <td className="td">{d.onu_count}</td>
                  <td className="td"><StatusBadge status={d.status} /></td>
                  <td className="td text-xs">{d.last_scan_at ? new Date(d.last_scan_at).toLocaleString() : "—"}</td>
                  <td className="td">
                    <div className="flex gap-1">
                      <button className="btn-ghost" disabled={!!busyId} onClick={() => test("olt", d.id)}>
                        {busyId === `test-olt-${d.id}` ? "..." : "Test"}
                      </button>
                      <button className="btn-ghost" disabled={!!busyId} onClick={() => scan("olt", d.id)}>
                        {busyId === `scan-olt-${d.id}` ? "..." : "Scan"}
                      </button>
                      <button className="btn-ghost" onClick={() => openEdit("olt", d)}>Edit</button>
                      <button className="btn-ghost text-red-600" onClick={() => remove("olt", d.id)}>Del</button>
                    </div>
                  </td>
                </tr>
              ))}
              {olts.length === 0 && (
                <tr><td className="td" colSpan={8}>No OLT devices configured yet.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </section>

      <section>
        <h2 className="mb-3 text-sm font-semibold uppercase tracking-wide text-slate-500">Mikrotik Servers</h2>
        <div className="card overflow-x-auto">
          <table className="w-full">
            <thead className="border-b border-slate-200 bg-slate-50">
              <tr>
                <th className="th">Name</th>
                <th className="th">IP</th>
                <th className="th">API</th>
                <th className="th">RouterOS</th>
                <th className="th">Status</th>
                <th className="th">Last scan</th>
                <th className="th">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {mikrotiks.map((d) => (
                <tr key={d.id} className="hover:bg-slate-50">
                  <td className="td font-medium">{d.name}</td>
                  <td className="td font-mono text-xs">{d.ip}</td>
                  <td className="td">{d.api_port}{d.use_ssl ? " (TLS)" : ""}</td>
                  <td className="td">v{d.routeros_version}</td>
                  <td className="td"><StatusBadge status={d.status} /></td>
                  <td className="td text-xs">{d.last_scan_at ? new Date(d.last_scan_at).toLocaleString() : "—"}</td>
                  <td className="td">
                    <div className="flex gap-1">
                      <button className="btn-ghost" disabled={!!busyId} onClick={() => test("mikrotik", d.id)}>
                        {busyId === `test-mikrotik-${d.id}` ? "..." : "Test"}
                      </button>
                      <button className="btn-ghost" disabled={!!busyId} onClick={() => scan("mikrotik", d.id)}>
                        {busyId === `scan-mikrotik-${d.id}` ? "..." : "Scan"}
                      </button>
                      <button className="btn-ghost" onClick={() => openEdit("mikrotik", d)}>Edit</button>
                      <button className="btn-ghost text-red-600" onClick={() => remove("mikrotik", d.id)}>Del</button>
                    </div>
                  </td>
                </tr>
              ))}
              {mikrotiks.length === 0 && (
                <tr><td className="td" colSpan={7}>No Mikrotik servers configured yet.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </section>

      {modal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4" onClick={() => setModal(null)}>
          <div className="max-h-[90vh] w-full max-w-lg overflow-y-auto rounded-xl bg-white p-6 shadow-xl" onClick={(e) => e.stopPropagation()}>
            <h2 className="mb-4 text-lg font-bold text-slate-900">
              {modal.id ? "Edit" : "Add"} {modal.kind === "olt" ? "OLT Device" : "Mikrotik Server"}
            </h2>
            <form onSubmit={submit} className="space-y-3">
              <div>
                <label className="label">Name</label>
                <input className="input" value={modal.name} onChange={(e) => setModal({ ...modal, name: e.target.value })} required />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="label">IP Address</label>
                  <input className="input font-mono" value={modal.ip} onChange={(e) => setModal({ ...modal, ip: e.target.value })} required />
                </div>
                <div>
                  <label className="label">Enabled</label>
                  <select className="input" value={modal.enabled ? "1" : "0"} onChange={(e) => setModal({ ...modal, enabled: e.target.value === "1" })}>
                    <option value="1">Yes</option>
                    <option value="0">No</option>
                  </select>
                </div>
              </div>

              {modal.kind === "olt" && (
                <>
                  <div className="grid grid-cols-3 gap-3">
                    <div>
                      <label className="label">Vendor</label>
                      <select className="input" value={modal.vendor} onChange={(e) => setModal({ ...modal, vendor: e.target.value })}>
                        <option value="bdcom">BDCOM</option>
                        <option value="zte">ZTE</option>
                        <option value="huawei">Huawei</option>
                        <option value="other">Other</option>
                      </select>
                    </div>
                    <div>
                      <label className="label">PON type</label>
                      <select className="input" value={modal.pon_type} onChange={(e) => setModal({ ...modal, pon_type: e.target.value })}>
                        <option value="gpon">GPON</option>
                        <option value="epon">EPON</option>
                      </select>
                    </div>
                    <div>
                      <label className="label">Access</label>
                      <select className="input" value={modal.access_method} onChange={(e) => setModal({ ...modal, access_method: e.target.value })}>
                        <option value="telnet">Telnet</option>
                        <option value="ssh">SSH</option>
                        <option value="snmp">SNMP</option>
                      </select>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="label">Port ({modal.access_method})</label>
                      <input type="number" className="input" value={modal.port} onChange={(e) => setModal({ ...modal, port: Number(e.target.value) })} />
                    </div>
                    <div>
                      <label className="label">SNMP community</label>
                      <input className="input" value={modal.snmp_community} onChange={(e) => setModal({ ...modal, snmp_community: e.target.value })} />
                    </div>
                  </div>
                  <div className="grid grid-cols-3 gap-3">
                    <div>
                      <label className="label">Username</label>
                      <input className="input" value={modal.username} onChange={(e) => setModal({ ...modal, username: e.target.value })} />
                    </div>
                    <div>
                      <label className="label">Password</label>
                      <input className="input" type="password" value={modal.password} onChange={(e) => setModal({ ...modal, password: e.target.value })} />
                    </div>
                    <div>
                      <label className="label">Enable password</label>
                      <input className="input" type="password" value={modal.enable_password} onChange={(e) => setModal({ ...modal, enable_password: e.target.value })} />
                    </div>
                  </div>
                </>
              )}

              {modal.kind === "mikrotik" && (
                <>
                  <div className="grid grid-cols-3 gap-3">
                    <div>
                      <label className="label">API port</label>
                      <input type="number" className="input" value={modal.api_port} onChange={(e) => setModal({ ...modal, api_port: Number(e.target.value) })} />
                    </div>
                    <div>
                      <label className="label">RouterOS</label>
                      <select className="input" value={modal.routeros_version} onChange={(e) => setModal({ ...modal, routeros_version: Number(e.target.value) })}>
                        <option value={6}>v6</option>
                        <option value={7}>v7</option>
                      </select>
                    </div>
                    <div>
                      <label className="label">Use SSL</label>
                      <select className="input" value={modal.use_ssl ? "1" : "0"} onChange={(e) => setModal({ ...modal, use_ssl: e.target.value === "1" })}>
                        <option value="0">No</option>
                        <option value="1">Yes</option>
                      </select>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="label">Username</label>
                      <input className="input" value={modal.username} onChange={(e) => setModal({ ...modal, username: e.target.value })} />
                    </div>
                    <div>
                      <label className="label">Password</label>
                      <input className="input" type="password" value={modal.password} onChange={(e) => setModal({ ...modal, password: e.target.value })} />
                    </div>
                  </div>
                </>
              )}

              <div className="flex justify-end gap-2 pt-2">
                <button type="button" className="btn-secondary" onClick={() => setModal(null)}>Cancel</button>
                <button type="submit" className="btn-primary">Save</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}