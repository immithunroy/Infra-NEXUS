import { useEffect, useState } from "react";
import { api } from "../api/client";
import { DashboardSummary } from "../api/types";

function StatCard({ label, value, tone = "default", hint }: {
  label: string;
  value: string | number;
  tone?: "default" | "green" | "amber" | "red" | "brand";
  hint?: string;
}) {
  const tones: Record<string, string> = {
    default: "text-slate-900",
    green: "text-emerald-600",
    amber: "text-amber-600",
    red: "text-red-600",
    brand: "text-brand-600",
  };
  return (
    <div className="card p-5">
      <div className="text-xs font-semibold uppercase tracking-wide text-slate-500">{label}</div>
      <div className={`mt-2 text-3xl font-bold ${tones[tone]}`}>{value}</div>
      {hint && <div className="mt-1 text-xs text-slate-500">{hint}</div>}
    </div>
  );
}

export default function Dashboard() {
  const [data, setData] = useState<DashboardSummary | null>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    api.get<DashboardSummary>("/dashboard").then(setData).catch((e) => setError(String(e)));
  }, []);

  if (error) return <div className="text-red-600">Failed to load dashboard: {error}</div>;
  if (!data) return <div className="text-slate-500">Loading...</div>;

  const onlinePct = data.onu_total ? Math.round((data.onu_active / data.onu_total) * 100) : 0;

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-2xl font-bold text-slate-900">Dashboard</h1>
        <p className="text-sm text-slate-500">
          OLT and Mikrotik monitoring overview
          {data.last_scan && (
            <span className="ml-2 text-xs">last scan {new Date(data.last_scan).toLocaleString()}</span>
          )}
        </p>
      </header>

      <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
        <StatCard label="OLTs" value={data.olt_count} hint={`${data.olt_reachable} reachable`} tone={data.olt_count > 0 && data.olt_reachable < data.olt_count ? "amber" : "default"} />
        <StatCard label="Mikrotiks" value={data.mikrotik_count} />
        <StatCard label="ONUs / ONTs" value={data.onu_total} hint={`${data.onu_manual} manually added`} />
        <StatCard label="ONU online" value={`${onlinePct}%`} hint={`${data.onu_active} active of ${data.onu_total}`} tone={onlinePct >= 80 ? "green" : onlinePct >= 50 ? "amber" : "red"} />
      </div>

      <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
        <StatCard label="Bound MACs" value={data.matched_mac_count} hint="matched to Mikrotik" tone="brand" />
        <StatCard label="Unbound ONUs" value={data.onu_total - data.onu_bound} hint="no Mikrotik match yet" tone={data.onu_total - data.onu_bound > 0 ? "amber" : "default"} />
        <StatCard label="OLT MACs" value={data.olt_mac_count} hint="learned on PON ports" />
        <StatCard label="ARP entries" value={data.arp_mac_count} hint="from Mikrotik" />
      </div>

      <div className="card p-5">
        <h2 className="mb-2 text-sm font-semibold text-slate-900">How it works</h2>
        <ol className="list-inside list-decimal space-y-1 text-sm text-slate-600">
          <li>OLT devices are polled via SNMP / Telnet / SSH to collect ONUs and learned MACs.</li>
          <li>Mikrotik routers are polled via the RouterOS API for their ARP / DHCP lease tables.</li>
          <li>The MAC binding engine matches OLT MACs against Mikrotik ARP entries.</li>
          <li>Adding or removing an ONU/ONT here only changes the application inventory — it never touches the Mikrotik or the OLT.</li>
        </ol>
      </div>
    </div>
  );
}