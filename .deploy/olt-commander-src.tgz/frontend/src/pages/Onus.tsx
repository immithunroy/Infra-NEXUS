import { FormEvent, useEffect, useState } from "react";
import { api } from "../api/client";
import { OLTDevice, Onu } from "../api/types";

interface FilterState {
  olt_id: string;
  state: string;
  source: string;
  bound: string;
  search: string;
}

const emptyFilter: FilterState = { olt_id: "", state: "", source: "", bound: "", search: "" };

interface FormState {
  id?: number;
  olt_id: number;
  name: string;
  serial: string;
  mac: string;
  pon_port: string;
  onu_id: number;
  vlan: number;
  note: string;
}

const emptyForm = (olts: OLTDevice[]): FormState => ({
  olt_id: olts[0]?.id || 0,
  name: "",
  serial: "",
  mac: "",
  pon_port: "",
  onu_id: 0,
  vlan: 0,
  note: "",
});

function StateBadge({ state }: { state: string }) {
  const map: Record<string, string> = {
    active: "bg-emerald-100 text-emerald-700",
    inactive: "bg-amber-100 text-amber-700",
    offline: "bg-red-100 text-red-700",
    unknown: "bg-slate-100 text-slate-600",
  };
  return <span className={`badge ${map[state] || map.unknown}`}>{state}</span>;
}

export default function Onus() {
  const [onus, setOnus] = useState<Onu[]>([]);
  const [olts, setOlts] = useState<OLTDevice[]>([]);
  const [filter, setFilter] = useState<FilterState>(emptyFilter);
  const [modal, setModal] = useState<FormState | null>(null);
  const [notice, setNotice] = useState<{ text: string; ok: boolean } | null>(null);
  const [queryVersion, setQueryVersion] = useState(0);

  const flash = (text: string, ok = true) => {
    setNotice({ text, ok });
    setTimeout(() => setNotice(null), 5000);
  };

  useEffect(() => {
    api.get<OLTDevice[]>("/devices/olts").then(setOlts).catch(() => undefined);
  }, []);

  useEffect(() => {
    const params = new URLSearchParams();
    if (filter.olt_id) params.set("olt_id", filter.olt_id);
    if (filter.state) params.set("state", filter.state);
    if (filter.source) params.set("source", filter.source);
    if (filter.bound) params.set("bound", filter.bound === "1" ? "true" : "false");
    if (filter.search) params.set("search", filter.search);
    api
      .get<Onu[]>(`/onus?${params.toString()}`)
      .then(setOnus)
      .catch((e) => flash(String(e), false));
  }, [filter, queryVersion]);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!modal) return;
    try {
      if (modal.id) {
        await api.put(`/onus/${modal.id}`, {
          name: modal.name,
          serial: modal.serial,
          mac: modal.mac,
          pon_port: modal.pon_port,
          onu_id: modal.onu_id,
          vlan: modal.vlan,
          note: modal.note,
        });
        flash("ONU updated");
      } else {
        await api.post("/onus", {
          olt_id: modal.olt_id,
          name: modal.name,
          serial: modal.serial,
          mac: modal.mac,
          pon_port: modal.pon_port,
          onu_id: modal.onu_id,
          vlan: modal.vlan,
          note: modal.note,
        });
        flash("ONU added to inventory (Mikrotik / OLT untouched)");
      }
      setModal(null);
      setQueryVersion((v) => v + 1);
    } catch (err) {
      flash(err instanceof Error ? err.message : "Save failed", false);
    }
  };

  const remove = async (onu: Onu) => {
    if (!confirm(`Remove ONU ${onu.pon_port || onu.serial || onu.name} from the application?\n\nThis only affects the application inventory — nothing is changed on the Mikrotik or OLT.`)) return;
    try {
      await api.del(`/onus/${onu.id}`);
      flash("ONU removed from application inventory");
      setQueryVersion((v) => v + 1);
    } catch (err) {
      flash(err instanceof Error ? err.message : "Delete failed", false);
    }
  };

  return (
    <div className="space-y-6">
      <header className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">ONU / ONT Inventory</h1>
          <p className="text-sm text-slate-500">
            Adding or removing an ONU here only changes the application inventory — it never talks to the Mikrotik or the OLT.
          </p>
        </div>
        <button className="btn-primary" onClick={() => setModal(emptyForm(olts))}>+ Add ONU</button>
      </header>

      {notice && (
        <div className={`rounded-md px-4 py-2 text-sm ${notice.ok ? "bg-emerald-50 text-emerald-700" : "bg-red-50 text-red-700"}`}>
          {notice.text}
        </div>
      )}

      <div className="card flex flex-wrap items-end gap-3 p-4">
        <div>
          <label className="label">OLT</label>
          <select className="input w-48" value={filter.olt_id} onChange={(e) => setFilter({ ...filter, olt_id: e.target.value })}>
            <option value="">All</option>
            {olts.map((o) => <option key={o.id} value={o.id}>{o.name}</option>)}
          </select>
        </div>
        <div>
          <label className="label">State</label>
          <select className="input w-32" value={filter.state} onChange={(e) => setFilter({ ...filter, state: e.target.value })}>
            <option value="">All</option>
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
            <option value="offline">Offline</option>
            <option value="unknown">Unknown</option>
          </select>
        </div>
        <div>
          <label className="label">Source</label>
          <select className="input w-32" value={filter.source} onChange={(e) => setFilter({ ...filter, source: e.target.value })}>
            <option value="">All</option>
            <option value="manual">Manual</option>
            <option value="auto">Auto</option>
          </select>
        </div>
        <div>
          <label className="label">Binding</label>
          <select className="input w-32" value={filter.bound} onChange={(e) => setFilter({ ...filter, bound: e.target.value })}>
            <option value="">All</option>
            <option value="1">Bound</option>
            <option value="0">Unbound</option>
          </select>
        </div>
        <div className="flex-1">
          <label className="label">Search (name, SN, MAC, port)</label>
          <input className="input" value={filter.search} onChange={(e) => setFilter({ ...filter, search: e.target.value })} placeholder="e.g. BDCM12345678" />
        </div>
      </div>

      <div className="card overflow-x-auto">
        <table className="w-full">
          <thead className="border-b border-slate-200 bg-slate-50">
            <tr>
              <th className="th">OLT / Port</th>
              <th className="th">Name</th>
              <th className="th">Serial</th>
              <th className="th">MAC</th>
              <th className="th">State</th>
              <th className="th">RX / TX</th>
              <th className="th">Mikrotik IP</th>
              <th className="th">Source</th>
              <th className="th">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {onus.map((o) => (
              <tr key={o.id} className="hover:bg-slate-50">
                <td className="td">
                  <div className="font-medium">{o.olt_name}</div>
                  <div className="font-mono text-xs text-slate-500">{o.pon_port || "—"}</div>
                </td>
                <td className="td">
                  <div>{o.name || <span className="text-slate-400">—</span>}</div>
                  {o.vlan > 0 && <div className="text-xs text-slate-500">VLAN {o.vlan}</div>}
                </td>
                <td className="td font-mono text-xs">{o.serial || "—"}</td>
                <td className="td font-mono text-xs">{o.last_mac || o.mac || "—"}</td>
                <td className="td"><StateBadge state={o.state} /></td>
                <td className="td font-mono text-xs">
                  {o.rx_power != null || o.tx_power != null ? (
                    <>
                      <div className={o.rx_power != null && o.rx_power < -25 ? "text-red-600" : ""}>
                        RX {o.rx_power ?? "—"} dBm
                      </div>
                      <div>TX {o.tx_power ?? "—"} dBm</div>
                    </>
                  ) : "—"}
                </td>
                <td className="td">
                  {o.bound ? (
                    <span className="badge bg-emerald-100 text-emerald-700">{o.mikrotik_ip || "bound"}</span>
                  ) : (
                    <span className="badge bg-slate-100 text-slate-500">unbound</span>
                  )}
                </td>
                <td className="td">
                  <span className={`badge ${o.source === "manual" ? "bg-brand-100 text-brand-700" : "bg-slate-100 text-slate-600"}`}>
                    {o.source}
                  </span>
                </td>
                <td className="td">
                  <div className="flex gap-1">
                    <button className="btn-ghost" onClick={() => setModal({
                      id: o.id, olt_id: o.olt_id, name: o.name, serial: o.serial, mac: o.mac,
                      pon_port: o.pon_port, onu_id: o.onu_id, vlan: o.vlan, note: o.note,
                    })}>Edit</button>
                    <button className="btn-ghost text-red-600" onClick={() => remove(o)}>Remove</button>
                  </div>
                </td>
              </tr>
            ))}
            {onus.length === 0 && (
              <tr><td className="td" colSpan={9}>No ONUs found. Add one manually or run a scan on an OLT.</td></tr>
            )}
          </tbody>
        </table>
      </div>

      {modal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4" onClick={() => setModal(null)}>
          <div className="max-h-[90vh] w-full max-w-lg overflow-y-auto rounded-xl bg-white p-6 shadow-xl" onClick={(e) => e.stopPropagation()}>
            <h2 className="mb-4 text-lg font-bold text-slate-900">
              {modal.id ? "Edit ONU" : "Add ONU to inventory"}
            </h2>
            {!modal.id && (
              <p className="mb-3 rounded-md bg-brand-50 px-3 py-2 text-xs text-brand-700">
                This only stores the ONU in the application. Nothing is sent to the Mikrotik or the OLT.
              </p>
            )}
            <form onSubmit={submit} className="space-y-3">
              {!modal.id && (
                <div>
                  <label className="label">OLT</label>
                  <select className="input" value={modal.olt_id} onChange={(e) => setModal({ ...modal, olt_id: Number(e.target.value) })} required>
                    <option value={0} disabled>Select OLT...</option>
                    {olts.map((o) => <option key={o.id} value={o.id}>{o.name}</option>)}
                  </select>
                </div>
              )}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="label">Customer / Name</label>
                  <input className="input" value={modal.name} onChange={(e) => setModal({ ...modal, name: e.target.value })} />
                </div>
                <div>
                  <label className="label">PON port (e.g. GPON0/1:5)</label>
                  <input className="input font-mono" value={modal.pon_port} onChange={(e) => setModal({ ...modal, pon_port: e.target.value })} placeholder="GPON0/1:5" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="label">ONU serial</label>
                  <input className="input font-mono" value={modal.serial} onChange={(e) => setModal({ ...modal, serial: e.target.value })} placeholder="BDCM12345678" />
                </div>
                <div>
                  <label className="label">ONU MAC</label>
                  <input className="input font-mono" value={modal.mac} onChange={(e) => setModal({ ...modal, mac: e.target.value })} placeholder="fc:fa:f7:9d:00:ea" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="label">ONU ID</label>
                  <input type="number" className="input" value={modal.onu_id} onChange={(e) => setModal({ ...modal, onu_id: Number(e.target.value) })} />
                </div>
                <div>
                  <label className="label">VLAN</label>
                  <input type="number" className="input" value={modal.vlan} onChange={(e) => setModal({ ...modal, vlan: Number(e.target.value) })} />
                </div>
              </div>
              <div>
                <label className="label">Note</label>
                <input className="input" value={modal.note} onChange={(e) => setModal({ ...modal, note: e.target.value })} />
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <button type="button" className="btn-secondary" onClick={() => setModal(null)}>Cancel</button>
                <button type="submit" className="btn-primary">Save</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}