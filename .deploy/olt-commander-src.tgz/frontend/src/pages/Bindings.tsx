import { useEffect, useState } from "react";
import { api } from "../api/client";
import { ArpEntry, Binding, MacEntry } from "../api/types";

export default function Bindings() {
  const [bindings, setBindings] = useState<Binding[]>([]);
  const [filter, setFilter] = useState<string>("");
  const [running, setRunning] = useState(false);
  const [notice, setNotice] = useState<{ text: string; ok: boolean } | null>(null);

  const load = async () => {
    setBindings(await api.get<Binding[]>(`/bindings${filter === "bound" ? "?bound=true" : filter === "unbound" ? "?bound=false" : ""}`));
  };

  useEffect(() => {
    load().catch((e) => setNotice({ text: String(e), ok: false }));
  }, [filter]);

  const run = async () => {
    setRunning(true);
    try {
      const summary = await api.post<{ matched: number; unmatched: number; total_macs: number; total_arp: number }>("/bindings/run");
      setNotice({ text: `Binding run complete: ${summary.matched} matched, ${summary.unmatched} unmatched (${summary.total_macs} OLT MACs, ${summary.total_arp} ARP)`, ok: true });
      await load();
    } catch (err) {
      setNotice({ text: err instanceof Error ? err.message : "Binding run failed", ok: false });
    } finally {
      setRunning(false);
    }
  };

  const boundCount = bindings.filter((b) => b.bound).length;

  return (
    <div className="space-y-6">
      <header className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">MAC Bindings</h1>
          <p className="text-sm text-slate-500">
            OLT learned MACs compared against the Mikrotik ARP / DHCP table. {boundCount} of {bindings.length} matched.
          </p>
        </div>
        <button className="btn-primary" onClick={run} disabled={running}>
          {running ? "Running..." : "Run binding comparison"}
        </button>
      </header>

      {notice && (
        <div className={`rounded-md px-4 py-2 text-sm ${notice.ok ? "bg-emerald-50 text-emerald-700" : "bg-red-50 text-red-700"}`}>
          {notice.text}
        </div>
      )}

      <div className="card flex items-center gap-3 p-4">
        <div>
          <label className="label">Filter</label>
          <select className="input w-40" value={filter} onChange={(e) => setFilter(e.target.value)}>
            <option value="">All</option>
            <option value="bound">Bound</option>
            <option value="unbound">Unbound</option>
          </select>
        </div>
      </div>

      <div className="card overflow-x-auto">
        <table className="w-full">
          <thead className="border-b border-slate-200 bg-slate-50">
            <tr>
              <th className="th">MAC Address</th>
              <th className="th">OLT</th>
              <th className="th">PON Port</th>
              <th className="th">ONU</th>
              <th className="th">Mikrotik</th>
              <th className="th">IP</th>
              <th className="th">Interface</th>
              <th className="th">Status</th>
              <th className="th">Checked</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {bindings.map((b) => (
              <tr key={`${b.mac}-${b.olt_id}`} className="hover:bg-slate-50">
                <td className="td font-mono text-xs font-medium">{b.mac}</td>
                <td className="td">{b.olt_name}</td>
                <td className="td font-mono text-xs">{b.olt_port || "—"}</td>
                <td className="td">{b.onu_name || <span className="text-slate-400">—</span>}</td>
                <td className="td">{b.mikrotik_name || <span className="text-slate-400">—</span>}</td>
                <td className="td font-mono text-xs">{b.mikrotik_ip || "—"}</td>
                <td className="td font-mono text-xs">{b.mikrotik_interface || "—"}</td>
                <td className="td">
                  {b.bound ? (
                    <span className="badge bg-emerald-100 text-emerald-700">BOUND</span>
                  ) : (
                    <span className="badge bg-amber-100 text-amber-700">UNBOUND</span>
                  )}
                </td>
                <td className="td text-xs">{new Date(b.last_checked).toLocaleString()}</td>
              </tr>
            ))}
            {bindings.length === 0 && (
              <tr><td className="td" colSpan={9}>
                No binding data yet. Scan an OLT and a Mikrotik, then run the binding comparison.
              </td></tr>
            )}
          </tbody>
        </table>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <MacTable />
        <ArpTable />
      </div>
    </div>
  );
}

function MacTable() {
  const [rows, setRows] = useState<MacEntry[]>([]);
  useEffect(() => {
    api.get<MacEntry[]>("/bindings/olts").then(setRows).catch(() => undefined);
  }, []);
  return (
    <div className="card overflow-x-auto">
      <div className="border-b border-slate-200 px-4 py-3 text-sm font-semibold text-slate-900">
        OLT learned MACs ({rows.length})
      </div>
      <table className="w-full">
        <thead className="border-b border-slate-200 bg-slate-50">
          <tr>
            <th className="th">MAC</th>
            <th className="th">OLT</th>
            <th className="th">Port</th>
            <th className="th">VLAN</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-100">
          {rows.slice(0, 100).map((r, i) => (
            <tr key={i}>
              <td className="td font-mono text-xs">{r.mac}</td>
              <td className="td">{r.olt_name}</td>
              <td className="td font-mono text-xs">{r.port}</td>
              <td className="td">{r.vlan || "—"}</td>
            </tr>
          ))}
          {rows.length === 0 && <tr><td className="td" colSpan={4}>No MACs collected from OLTs yet.</td></tr>}
        </tbody>
      </table>
    </div>
  );
}

function ArpTable() {
  const [rows, setRows] = useState<ArpEntry[]>([]);
  useEffect(() => {
    api.get<ArpEntry[]>("/bindings/mikrotik").then(setRows).catch(() => undefined);
  }, []);
  return (
    <div className="card overflow-x-auto">
      <div className="border-b border-slate-200 px-4 py-3 text-sm font-semibold text-slate-900">
        Mikrotik ARP / DHCP ({rows.length})
      </div>
      <table className="w-full">
        <thead className="border-b border-slate-200 bg-slate-50">
          <tr>
            <th className="th">MAC</th>
            <th className="th">Device</th>
            <th className="th">IP</th>
            <th className="th">Interface</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-100">
          {rows.slice(0, 100).map((r, i) => (
            <tr key={i}>
              <td className="td font-mono text-xs">{r.mac}</td>
              <td className="td">{r.device_name}</td>
              <td className="td font-mono text-xs">{r.ip || "—"}</td>
              <td className="td font-mono text-xs">{r.interface || "—"}</td>
            </tr>
          ))}
          {rows.length === 0 && <tr><td className="td" colSpan={4}>No ARP entries collected yet.</td></tr>}
        </tbody>
      </table>
    </div>
  );
}