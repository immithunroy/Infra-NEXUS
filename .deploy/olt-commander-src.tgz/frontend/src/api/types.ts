export interface TokenResponse {
  access_token: string;
  token_type: string;
}

export interface UserOut {
  id: number;
  username: string;
  is_admin: boolean;
}

export interface OLTDevice {
  id: number;
  name: string;
  ip: string;
  vendor: string;
  pon_type: string;
  access_method: string;
  port: number;
  username: string;
  password: string;
  enable_password: string;
  snmp_community: string;
  snmp_version: string;
  snmp_port: number;
  enabled: boolean;
  status: string;
  last_scan_at: string | null;
  last_message: string;
  onu_count: number;
}

export interface MikrotikDevice {
  id: number;
  name: string;
  ip: string;
  api_port: number;
  use_ssl: boolean;
  routeros_version: number;
  username: string;
  password: string;
  enabled: boolean;
  status: string;
  last_scan_at: string | null;
  last_message: string;
}

export interface Onu {
  id: number;
  olt_id: number;
  olt_name: string;
  source: string;
  state: string;
  name: string;
  serial: string;
  mac: string;
  pon_port: string;
  onu_id: number;
  vlan: number;
  rx_power: number | null;
  tx_power: number | null;
  last_mac: string;
  mikrotik_ip: string;
  bound: boolean;
  note: string;
  last_seen: string | null;
  created_at: string;
}

export interface Binding {
  mac: string;
  olt_id: number;
  olt_name: string;
  olt_port: string;
  mikrotik_id: number | null;
  mikrotik_name: string;
  mikrotik_ip: string;
  mikrotik_interface: string;
  onu_id: number | null;
  onu_name: string;
  bound: boolean;
  last_checked: string;
}

export interface MacEntry {
  mac: string;
  port: string;
  vlan: number;
  last_seen: string;
  olt_id: number;
  olt_name: string;
}

export interface ArpEntry {
  mac: string;
  ip: string;
  interface: string;
  last_seen: string;
  device_id: number;
  device_name: string;
}

export interface DashboardSummary {
  olt_count: number;
  olt_reachable: number;
  mikrotik_count: number;
  onu_total: number;
  onu_manual: number;
  onu_active: number;
  onu_inactive: number;
  onu_bound: number;
  olt_mac_count: number;
  arp_mac_count: number;
  matched_mac_count: number;
  last_scan: string | null;
}

export interface ScanLog {
  id: number;
  scan_type: string;
  device_id: number;
  device_name: string;
  status: string;
  message: string;
  started_at: string;
  finished_at: string | null;
}

export interface TestResult {
  success: boolean;
  message: string;
}