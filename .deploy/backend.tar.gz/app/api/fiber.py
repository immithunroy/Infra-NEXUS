from fastapi import APIRouter, Depends, HTTPException, UploadFile, File
from fastapi.responses import StreamingResponse
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
import io

from ..database import get_db
from ..models import Cable, CableSegment, TjBox, Splitter, User
from ..schemas import (
    CableCreate, CableOut, CableUpdate,
    TjBoxCreate, TjBoxOut, TjBoxUpdate,
    SplitterCreate, SplitterOut, SplitterUpdate,
)
from ..security import get_current_user, require_write

router = APIRouter(prefix="/api/fiber", tags=["fiber"], dependencies=[Depends(get_current_user)])


# ------------------------------------------------------------------ Cables
@router.get("/cables", response_model=list[CableOut])
async def list_cables(db: AsyncSession = Depends(get_db)):
    res = await db.execute(select(Cable).order_by(Cable.id))
    cables = res.scalars().all()
    result = []
    for c in cables:
        seg_res = await db.execute(select(CableSegment).where(CableSegment.cable_id == c.id).order_by(CableSegment.order_index))
        c.segments = seg_res.scalars().all()
        result.append(c)
    return result


@router.post("/cables", response_model=CableOut)
async def create_cable(body: CableCreate, user: User = Depends(require_write), db: AsyncSession = Depends(get_db)):
    cable = Cable(
        code=body.code, core_count=body.core_count, manufacturer=body.manufacturer,
        manufacturing_year=body.manufacturing_year, cable_type=body.cable_type,
        color=body.color, notes=body.notes,
    )
    db.add(cable)
    await db.flush()
    for i, seg in enumerate(body.segments):
        db.add(CableSegment(
            cable_id=cable.id, start_lat=seg.start_lat, start_lng=seg.start_lng,
            end_lat=seg.end_lat, end_lng=seg.end_lng, order_index=i,
        ))
    await db.commit()
    await db.refresh(cable)
    seg_res = await db.execute(select(CableSegment).where(CableSegment.cable_id == cable.id).order_by(CableSegment.order_index))
    cable.segments = seg_res.scalars().all()
    return cable


@router.put("/cables/{cable_id}", response_model=CableOut)
async def update_cable(cable_id: int, body: CableUpdate, user: User = Depends(require_write), db: AsyncSession = Depends(get_db)):
    cable = await db.get(Cable, cable_id)
    if cable is None:
        raise HTTPException(status_code=404, detail="Cable not found")
    for field, value in body.model_dump(exclude_unset=True, exclude={"segments"}).items():
        setattr(cable, field, value)
    if body.segments is not None:
        from sqlalchemy import delete
        await db.execute(delete(CableSegment).where(CableSegment.cable_id == cable_id))
        for i, seg in enumerate(body.segments):
            db.add(CableSegment(
                cable_id=cable_id, start_lat=seg.start_lat, start_lng=seg.start_lng,
                end_lat=seg.end_lat, end_lng=seg.end_lng, order_index=i,
            ))
    await db.commit()
    await db.refresh(cable)
    seg_res = await db.execute(select(CableSegment).where(CableSegment.cable_id == cable.id).order_by(CableSegment.order_index))
    cable.segments = seg_res.scalars().all()
    return cable


@router.delete("/cables/{cable_id}", status_code=204)
async def delete_cable(cable_id: int, user: User = Depends(require_write), db: AsyncSession = Depends(get_db)):
    cable = await db.get(Cable, cable_id)
    if cable is None:
        raise HTTPException(status_code=404, detail="Cable not found")
    await db.delete(cable)
    await db.commit()


# ------------------------------------------------------------------ TJ Boxes
@router.get("/tj-boxes", response_model=list[TjBoxOut])
async def list_tj_boxes(db: AsyncSession = Depends(get_db)):
    res = await db.execute(select(TjBox).order_by(TjBox.id))
    return res.scalars().all()


@router.post("/tj-boxes", response_model=TjBoxOut)
async def create_tj_box(body: TjBoxCreate, user: User = Depends(require_write), db: AsyncSession = Depends(get_db)):
    res = await db.execute(select(TjBox.unique_id).where(TjBox.unique_id.like("TJ-%")).order_by(TjBox.id.desc()).limit(1))
    last = res.scalar()
    next_num = 5001
    if last:
        try:
            next_num = int(last.split("-")[1]) + 1
        except (IndexError, ValueError):
            pass
    box = TjBox(unique_id=f"TJ-{next_num}", **body.model_dump())
    db.add(box)
    await db.commit()
    await db.refresh(box)
    return box


@router.put("/tj-boxes/{box_id}", response_model=TjBoxOut)
async def update_tj_box(box_id: int, body: TjBoxUpdate, user: User = Depends(require_write), db: AsyncSession = Depends(get_db)):
    box = await db.get(TjBox, box_id)
    if box is None:
        raise HTTPException(status_code=404, detail="TJ Box not found")
    for field, value in body.model_dump(exclude_unset=True).items():
        setattr(box, field, value)
    await db.commit()
    await db.refresh(box)
    return box


@router.delete("/tj-boxes/{box_id}", status_code=204)
async def delete_tj_box(box_id: int, user: User = Depends(require_write), db: AsyncSession = Depends(get_db)):
    box = await db.get(TjBox, box_id)
    if box is None:
        raise HTTPException(status_code=404, detail="TJ Box not found")
    # Delete hosted splitters first
    splitters = (await db.execute(select(Splitter).where(Splitter.tj_box_id == box_id))).scalars().all()
    for sp in splitters:
        await db.delete(sp)
    await db.delete(box)
    await db.commit()


# ------------------------------------------------------------------ Splitters
@router.get("/splitters", response_model=list[SplitterOut])
async def list_splitters(db: AsyncSession = Depends(get_db)):
    res = await db.execute(select(Splitter).order_by(Splitter.id))
    splitters = res.scalars().all()
    result = []
    for s in splitters:
        if s.tj_box_id:
            box = await db.get(TjBox, s.tj_box_id)
            s.tj_box_name = box.name if box else ""
        result.append(s)
    return result


@router.post("/splitters", response_model=SplitterOut)
async def create_splitter(body: SplitterCreate, user: User = Depends(require_write), db: AsyncSession = Depends(get_db)):
    res = await db.execute(select(Splitter.unique_id).where(Splitter.unique_id.like("SP-%")).order_by(Splitter.id.desc()).limit(1))
    last = res.scalar()
    next_num = 1001
    if last:
        try:
            next_num = int(last.split("-")[1]) + 1
        except (IndexError, ValueError):
            pass
    splitter = Splitter(unique_id=f"SP-{next_num}", **body.model_dump())
    db.add(splitter)
    await db.commit()
    await db.refresh(splitter)
    return splitter


@router.put("/splitters/{splitter_id}", response_model=SplitterOut)
async def update_splitter(splitter_id: int, body: SplitterUpdate, user: User = Depends(require_write), db: AsyncSession = Depends(get_db)):
    splitter = await db.get(Splitter, splitter_id)
    if splitter is None:
        raise HTTPException(status_code=404, detail="Splitter not found")
    for field, value in body.model_dump(exclude_unset=True).items():
        setattr(splitter, field, value)
    await db.commit()
    await db.refresh(splitter)
    return splitter


@router.delete("/splitters/{splitter_id}", status_code=204)
async def delete_splitter(splitter_id: int, user: User = Depends(require_write), db: AsyncSession = Depends(get_db)):
    splitter = await db.get(Splitter, splitter_id)
    if splitter is None:
        raise HTTPException(status_code=404, detail="Splitter not found")
    await db.delete(splitter)
    await db.commit()


# ------------------------------------------------------------ Export / Import
@router.get("/export")
async def export_fiber(db: AsyncSession = Depends(get_db)):
    import openpyxl
    wb = openpyxl.Workbook()

    # TJ Boxes sheet
    ws = wb.active
    ws.title = "TJ Boxes"
    ws.append(["Name", "Type", "Capacity", "Trays", "Latitude", "Longitude", "Address", "Notes"])
    res = await db.execute(select(TjBox).order_by(TjBox.id))
    for t in res.scalars().all():
        ws.append([t.name, t.box_type, t.capacity, t.tray_count, t.lat, t.lng, t.address, t.notes])

    # Splitters sheet
    ws2 = wb.create_sheet("Splitters")
    ws2.append(["Name", "Split Ratio", "TJ Box Name", "Input Core", "Output Cores", "Latitude", "Longitude", "Notes"])
    res = await db.execute(select(Splitter).order_by(Splitter.id))
    for s in res.scalars().all():
        box_name = ""
        if s.tj_box_id:
            box = await db.get(TjBox, s.tj_box_id)
            box_name = box.name if box else ""
        ws2.append([s.name, s.split_ratio, box_name, s.input_core, s.output_cores, s.lat, s.lng, s.notes])

    # Cables sheet
    ws3 = wb.create_sheet("Cables")
    ws3.append(["Code", "Core Count", "Type", "Manufacturer", "Year", "Color", "Notes", "Segment Lat", "Segment Lng", "Segment End Lat", "Segment End Lng"])
    res = await db.execute(select(Cable).order_by(Cable.id))
    for c in res.scalars().all():
        segs = (await db.execute(select(CableSegment).where(CableSegment.cable_id == c.id).order_by(CableSegment.order_index))).scalars().all()
        if segs:
            for seg in segs:
                ws3.append([c.code, c.core_count, c.cable_type, c.manufacturer, c.manufacturing_year, c.color, c.notes,
                            seg.start_lat, seg.start_lng, seg.end_lat, seg.end_lng])
        else:
            ws3.append([c.code, c.core_count, c.cable_type, c.manufacturer, c.manufacturing_year, c.color, c.notes, "", "", "", ""])

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return StreamingResponse(buf, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": "attachment; filename=fiber_network.xlsx"})


@router.post("/import")
async def import_fiber(file: UploadFile = File(...), user: User = Depends(require_write), db: AsyncSession = Depends(get_db)):
    import openpyxl
    content = await file.read()
    wb = openpyxl.load_workbook(io.BytesIO(content))
    imported = {"tj_boxes": 0, "splitters": 0, "cables": 0}

    # Find next IDs
    res = await db.execute(select(TjBox.unique_id).where(TjBox.unique_id.like("TJ-%")).order_by(TjBox.id.desc()).limit(1))
    last = res.scalar()
    tj_next = 5001
    if last:
        try: tj_next = int(last.split("-")[1]) + 1
        except: pass

    res = await db.execute(select(Splitter.unique_id).where(Splitter.unique_id.like("SP-%")).order_by(Splitter.id.desc()).limit(1))
    last = res.scalar()
    sp_next = 1001
    if last:
        try: sp_next = int(last.split("-")[1]) + 1
        except: pass

    # TJ Boxes
    if "TJ Boxes" in wb.sheetnames:
        ws = wb["TJ Boxes"]
        for row in ws.iter_rows(min_row=2, values_only=True):
            if not row[0]:
                continue
            box = TjBox(
                unique_id=f"TJ-{tj_next}",
                name=str(row[0] or ""), box_type=str(row[1] or "tj"),
                capacity=int(row[2] or 4), tray_count=int(row[3] or 1),
                lat=float(row[4] or 0), lng=float(row[5] or 0),
                address=str(row[6] or ""), notes=str(row[7] or ""),
            )
            db.add(box)
            tj_next += 1
            imported["tj_boxes"] += 1

    # Splitters
    if "Splitters" in wb.sheetnames:
        ws = wb["Splitters"]
        for row in ws.iter_rows(min_row=2, values_only=True):
            if not row[4] or not row[5]:
                continue
            tj_box_id = None
            if row[2]:
                box_res = await db.execute(select(TjBox).where(TjBox.name == str(row[2])))
                box = box_res.scalars().first()
                if box:
                    tj_box_id = box.id
            splitter = Splitter(
                unique_id=f"SP-{sp_next}",
                name=str(row[0] or ""), split_ratio=int(row[1] or 2),
                tj_box_id=tj_box_id, input_core=int(row[3] or 0),
                output_cores=str(row[4] or ""),
                lat=float(row[5] or 0), lng=float(row[6] or 0),
                notes=str(row[7] or ""),
            )
            db.add(splitter)
            sp_next += 1
            imported["splitters"] += 1

    # Cables
    if "Cables" in wb.sheetnames:
        ws = wb["Cables"]
        cable_cache: dict[str, Cable] = {}
        for row in ws.iter_rows(min_row=2, values_only=True):
            if not row[0]:
                continue
            code = str(row[0])
            if code not in cable_cache:
                cable = Cable(
                    code=code, core_count=int(row[1] or 12), cable_type=str(row[2] or "round"),
                    manufacturer=str(row[3] or ""), manufacturing_year=int(row[4] or 0),
                    color=str(row[5] or ""), notes=str(row[6] or ""),
                )
                db.add(cable)
                await db.flush()
                cable_cache[code] = cable
                imported["cables"] += 1
            if row[7] and row[8] and row[9] and row[10]:
                seg = CableSegment(
                    cable_id=cable_cache[code].id,
                    start_lat=float(row[7]), start_lng=float(row[8]),
                    end_lat=float(row[9]), end_lng=float(row[10]),
                )
                db.add(seg)

    await db.commit()
    return imported
