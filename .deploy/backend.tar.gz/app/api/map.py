from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from ..database import get_db
from ..models import OLTDevice, Onu, User
from ..schemas import MapPoint, MapPointResponse
from ..security import get_current_user
from ..utils.status import display_status

router = APIRouter(prefix="/api/map", tags=["map"], dependencies=[Depends(get_current_user)])

# Markers with no GPS fix but a recorded address fall back to the city center.
CITY_LAT = 22.7000
CITY_LNG = 90.3667


@router.get("/points", response_model=MapPointResponse)
async def map_points(db: AsyncSession = Depends(get_db)):
    """ONUs that have GPS coordinates (or an address) for the network map.

    status is the combined display status (pppoe/up/power_off/wire_down/
    inactive/offline/unknown) so the map can colour online vs offline vs
    outage-area markers.
    """
    onus = (
        await db.execute(select(Onu).order_by(Onu.olt_id, Onu.pon_port, Onu.onu_id))
    ).scalars().all()
    olts = {d.id: d for d in (await db.execute(select(OLTDevice))).scalars()}

    points: list[MapPoint] = []
    for o in onus:
        if o.gps_lat is None or o.gps_lng is None:
            continue
        state = o.state.value if hasattr(o.state, "value") else str(o.state)
        olt = olts.get(o.olt_id)
        points.append(
            MapPoint(
                onu_id=o.id,
                olt_id=o.olt_id,
                olt_name=olt.name if olt else "",
                pon_port=o.pon_port,
                name=o.name,
                subscriber=o.subscriber,
                serial=o.serial,
                gps_lat=o.gps_lat,
                gps_lng=o.gps_lng,
                gps_accuracy=o.gps_accuracy,
                state=state,
                status=display_status(state, o.bound, o.down_reason or ""),
                down_reason=o.down_reason or "",
                bound=o.bound,
                rx_power=o.rx_power,
                address=o.address,
                last_seen=o.last_seen,
            )
        )
    return MapPointResponse(city_lat=CITY_LAT, city_lng=CITY_LNG, points=points)
