from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


class LoginRequest(BaseModel):
    username: str
    password: str


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"


class UserOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    username: str
    role: str = "admin"
    is_admin: bool


class UserCreate(BaseModel):
    username: str
    password: str
    role: str = "global_read"


class UserUpdate(BaseModel):
    username: str | None = None
    password: str | None = None
    role: str | None = None
    is_admin: bool | None = None


class OLTDeviceBase(BaseModel):
    name: str
    ip: str
    vendor: str = "bdcom"
    pon_type: str = "gpon"
    access_method: str = "telnet"
    port: int = 23
    username: str = ""
    password: str = ""
    enable_password: str = ""
    snmp_community: str = "public"
    snmp_version: str = "2c"
    snmp_port: int = 161
    snmp_enabled: bool = False
    port_capacity: int = 32
    enabled: bool = True


class OLTDeviceCreate(OLTDeviceBase):
    pass


class OLTDeviceUpdate(BaseModel):
    name: str | None = None
    ip: str | None = None
    vendor: str | None = None
    pon_type: str | None = None
    access_method: str | None = None
    port: int | None = None
    username: str | None = None
    password: str | None = None
    enable_password: str | None = None
    snmp_community: str | None = None
    snmp_version: str | None = None
    snmp_port: int | None = None
    snmp_enabled: bool | None = None
    port_capacity: int | None = None
    enabled: bool | None = None


class OLTDeviceOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    name: str
    ip: str
    vendor: str
    pon_type: str
    access_method: str
    port: int
    username: str
    password: str = ""
    enable_password: str = ""
    snmp_community: str
    snmp_version: str
    snmp_port: int
    snmp_enabled: bool
    port_capacity: int
    enabled: bool
    status: str
    last_scan_at: datetime | None
    last_message: str
    onu_count: int = 0
    ports: list[str] = []


class SwitchBase(BaseModel):
    name: str
    ip: str
    vendor: str = "bdcom"
    port_count: int = 24
    access_method: str = "telnet"
    port: int = 23
    username: str = ""
    password: str = ""
    enable_password: str = ""
    snmp_enabled: bool = False
    snmp_community: str = "public"
    enabled: bool = True


class SwitchCreate(SwitchBase):
    pass


class SwitchUpdate(BaseModel):
    name: str | None = None
    ip: str | None = None
    vendor: str | None = None
    port_count: int | None = None
    access_method: str | None = None
    port: int | None = None
    username: str | None = None
    password: str | None = None
    enable_password: str | None = None
    snmp_enabled: bool | None = None
    snmp_community: str | None = None
    enabled: bool | None = None


class SwitchOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    name: str
    ip: str
    vendor: str
    port_count: int
    access_method: str
    port: int
    username: str
    password: str = ""
    enable_password: str = ""
    snmp_enabled: bool
    snmp_community: str
    enabled: bool
    status: str
    last_scan_at: datetime | None
    last_message: str
    ports: list["SwitchPortOut"] = []


class SwitchPortOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    switch_id: int
    name: str
    status: str
    speed: str
    vlan: str
    mac_address: str
    description: str
    last_scan_at: datetime | None


class MikrotikBase(BaseModel):
    name: str
    ip: str
    api_port: int = 8728
    use_ssl: bool = False
    routeros_version: int = 6
    username: str = ""
    password: str = ""
    enabled: bool = True


class MikrotikCreate(MikrotikBase):
    pass


class MikrotikUpdate(BaseModel):
    name: str | None = None
    ip: str | None = None
    api_port: int | None = None
    use_ssl: bool | None = None
    routeros_version: int | None = None
    username: str | None = None
    password: str | None = None
    enabled: bool | None = None


class MikrotikOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    name: str
    ip: str
    api_port: int
    use_ssl: bool
    routeros_version: int
    username: str
    password: str = ""
    enabled: bool
    status: str
    last_scan_at: datetime | None
    last_message: str
    subscriber_count: int = 0  # total PPP secrets (authoritative total)
    active_count: int = 0  # currently connected PPPoE sessions


class OnuBase(BaseModel):
    name: str = ""
    serial: str = ""
    mac: str = ""
    pon_port: str = ""
    onu_id: int = 0
    vlan: int = 0
    note: str = ""


class OnuCreate(OnuBase):
    olt_id: int


class OnuUpdate(BaseModel):
    # subscriber is intentionally absent: it is managed by the binding
    # engine from the Mikrotik /ppp/active list only. extra="forbid" makes
    # sure any attempt to set it (or any other unknown field) is rejected.
    model_config = ConfigDict(extra="forbid")

    name: str | None = None
    serial: str | None = None
    mac: str | None = None
    pon_port: str | None = None
    onu_id: int | None = None
    vlan: int | None = None
    note: str | None = None
    address: str | None = None
    gps_lat: float | None = None
    gps_lng: float | None = None
    gps_accuracy: float | None = None
    phone: str | None = None
    email: str | None = None


class OnuOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    olt_id: int
    olt_name: str = ""
    source: str
    state: str
    name: str
    serial: str
    mac: str
    pon_port: str
    onu_id: int
    vlan: int
    rx_power: float | None
    tx_power: float | None
    last_mac: str
    mac_vendor: str = ""
    mikrotik_ip: str
    subscriber: str
    bound: bool
    down_reason: str = ""
    status: str = ""
    note: str
    address: str = ""
    gps_lat: float | None = None
    gps_lng: float | None = None
    gps_accuracy: float | None = None
    phone: str = ""
    email: str = ""
    last_seen: datetime | None
    created_at: datetime


class TestResult(BaseModel):
    success: bool
    message: str


class ScanResult(BaseModel):
    success: bool
    message: str
    log_id: int | None = None


class MacEntryOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    mac: str
    mac_vendor: str = ""
    port: str
    vlan: int
    last_seen: datetime
    olt_id: int
    olt_name: str = ""


class PppActiveOut(BaseModel):
    """A live PPPoE session from the Mikrotik /ppp/active table."""

    model_config = ConfigDict(from_attributes=True)

    mac: str
    mac_vendor: str = ""
    ip: str
    interface: str
    subscriber: str
    last_seen: datetime
    device_id: int
    device_name: str = ""


class BindingOut(BaseModel):
    mac: str
    mac_vendor: str = ""
    olt_id: int
    olt_name: str
    olt_port: str
    mikrotik_id: int | None
    mikrotik_name: str
    mikrotik_ip: str
    mikrotik_interface: str
    subscriber: str
    onu_id: int | None
    onu_name: str
    bound: bool
    last_checked: datetime


class PortUsage(BaseModel):
    port: str
    used: int
    capacity: int
    remaining: int
    active: int
    bound: int


class OltUsage(BaseModel):
    id: int
    name: str
    ip: str
    pon_type: str
    status: str
    port_capacity: int
    port_count: int
    total_slots: int
    used_slots: int
    free_slots: int
    utilization_pct: float
    onu_total: int
    onu_active: int
    onu_bound: int
    onu_manual: int
    ports: list[PortUsage]


class SignalBucket(BaseModel):
    label: str
    count: int


class WeakOnu(BaseModel):
    olt_id: int = 0
    olt_name: str = ""
    pon_port: str = ""
    onu_id: int = 0
    name: str = ""
    subscriber: str = ""
    serial: str = ""
    state: str = ""
    rx_power: float | None = None
    tx_power: float | None = None


class BrandBucket(BaseModel):
    brand: str
    count: int
    pct: float


class MassDownPort(BaseModel):
    olt_id: int
    olt_name: str
    port: str
    label: str = ""
    count: int
    power_off_count: int = 0
    wire_down_count: int = 0
    reason: str = ""


class MapPoint(BaseModel):
    onu_id: int
    olt_id: int
    olt_name: str = ""
    pon_port: str = ""
    name: str = ""
    subscriber: str = ""
    serial: str = ""
    gps_lat: float
    gps_lng: float
    gps_accuracy: float | None = None
    state: str
    status: str
    down_reason: str = ""
    bound: bool = False
    rx_power: float | None = None
    address: str = ""
    last_seen: datetime | None = None


class MapPointResponse(BaseModel):
    city_lat: float = 22.7000
    city_lng: float = 90.3667
    points: list[MapPoint] = []


class DashboardSummary(BaseModel):
    olt_count: int
    olt_reachable: int
    mikrotik_count: int
    onu_total: int
    onu_manual: int
    onu_active: int
    onu_inactive: int
    onu_bound: int
    olt_mac_count: int
    active_mac_count: int
    matched_mac_count: int
    total_slots: int
    free_slots: int
    bound_pct: float
    subscriber_total: int = 0  # sum of PPP secrets across Mikrotiks
    subscriber_active: int = 0  # currently connected PPPoE sessions
    signal_hist: list[SignalBucket]
    weakest_onus: list[WeakOnu]
    router_brands: list[BrandBucket] = []
    mass_down_ports: list[MassDownPort] = []
    olts: list[OltUsage]
    last_scan: datetime | None


class SearchOnu(BaseModel):
    id: int
    olt_id: int
    olt_name: str
    pon_port: str
    name: str
    serial: str
    subscriber: str
    last_mac: str
    mac_vendor: str = ""
    state: str
    bound: bool
    down_reason: str = ""
    status: str = ""


class SearchDevice(BaseModel):
    id: int
    name: str
    ip: str
    kind: str  # olt | mikrotik


class SearchResult(BaseModel):
    onus: list[SearchOnu]
    olts: list[SearchDevice]
    mikrotiks: list[SearchDevice]


class TelemetryPoint(BaseModel):
    sampled_at: datetime
    rx_power: float | None
    tx_power: float | None
    rx_mbps: float | None = None
    tx_mbps: float | None = None


class MacHistoryEntry(BaseModel):
    mac: str
    mac_vendor: str = ""
    changed_at: datetime


class SubscriberSummary(BaseModel):
    subscriber: str
    onu_id: int
    onu_name: str = ""
    olt_name: str = ""
    pon_port: str = ""
    last_mac: str = ""
    mac_vendor: str = ""
    mikrotik_ip: str = ""
    state: str = ""
    bound: bool = False
    down_reason: str = ""
    status: str = ""
    acs_device_id: int | None = None
    rx_power: float | None = None
    tx_power: float | None = None
    mac_change_count: int = 0
    last_seen: datetime | None = None


class RemotePort(BaseModel):
    port: int
    scheme: str
    open: bool


class RemoteAccess(BaseModel):
    ip: str
    reachable: bool
    url: str = ""
    ports: list[RemotePort] = []
    checked_at: float = 0


class SubscriberProfile(BaseModel):
    subscriber: str
    onu_id: int
    onu_name: str = ""
    olt_name: str = ""
    pon_port: str = ""
    serial: str = ""
    last_mac: str = ""
    mac_vendor: str = ""
    mikrotik_ip: str = ""
    state: str = ""
    bound: bool = False
    can_edit_gps: bool = False
    down_reason: str = ""
    status: str = ""
    acs_device_id: int | None = None
    address: str = ""
    gps_lat: float | None = None
    gps_lng: float | None = None
    gps_accuracy: float | None = None
    phone: str = ""
    email: str = ""
    note: str = ""
    telemetry: list[TelemetryPoint] = []
    mac_history: list[MacHistoryEntry] = []
    last_seen: datetime | None = None


class DownStartRequest(BaseModel):
    olt_id: int
    port: str = ""
    interval: int = 30
    mass_threshold: int = 5


class PortAreaOut(BaseModel):
    olt_id: int
    port: str
    label: str = ""


class PortAreaUpsert(BaseModel):
    olt_id: int
    port: str
    label: str = ""


class DownEventOut(BaseModel):
    id: int
    olt_id: int
    olt_name: str
    pon_port: str
    onu_id: int
    serial: str
    name: str
    kind: str
    reason: str
    detected_at: datetime
    duration_seconds: int | None = None
    outage_id: int | None = None


class DownStatusOut(BaseModel):
    running: bool
    olt_id: int | None = None
    olt_name: str = ""
    port: str = ""
    interval: int | None = None
    mass_threshold: int | None = None
    last_poll_at: datetime | None = None
    started_at: datetime | None = None
    last_error: str = ""
    current_down_count: int = 0
    current_down: list[dict] = []


class OutageOut(BaseModel):
    id: int
    olt_id: int
    olt_name: str
    pon_port: str
    started_at: datetime
    onu_count: int
    resolved_at: datetime | None = None
    resolved: bool


class ScanLogOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    scan_type: str
    device_id: int
    device_name: str
    status: str
    message: str
    started_at: datetime
    finished_at: datetime | None


class Message(BaseModel):
    detail: str = Field(default="")


class DownReasonBucket(BaseModel):
    reason: str
    count: int


class PortReport(BaseModel):
    port: str
    label: str = ""
    total: int = 0
    active: int = 0
    down: int = 0
    bound: int = 0
    gps: int = 0
    online_pct: float = 0.0


class OltReport(BaseModel):
    olt_id: int
    olt_name: str
    pon_type: str = ""
    port_count: int = 0
    total: int = 0
    active: int = 0
    down: int = 0
    bound: int = 0
    gps: int = 0
    online_pct: float = 0.0
    ports: list[PortReport] = []


class ReportSummary(BaseModel):
    total_onus: int = 0
    total_active: int = 0
    total_down: int = 0
    total_bound: int = 0
    gps_tagged: int = 0
    gps_coverage_pct: float = 0.0
    state: dict[str, int] = {}
    down_reasons: list[DownReasonBucket] = []
    recent_down_events: int = 0
    recent_down_events_by_reason: list[DownReasonBucket] = []
    olts: list[OltReport] = []


class TicketCreate(BaseModel):
    title: str
    description: str = ""
    priority: str = "normal"
    assigned_to: int | None = None
    subscriber: str = ""
    onu_id: int | None = None


class TicketUpdate(BaseModel):
    title: str | None = None
    description: str | None = None
    status: str | None = None
    priority: str | None = None
    assigned_to: int | None = None
    subscriber: str | None = None
    onu_id: int | None = None


class TicketOut(BaseModel):
    id: int
    title: str
    description: str
    status: str
    priority: str
    assigned_to: int | None = None
    assigned_name: str = ""
    created_by: int | None = None
    created_by_name: str = ""
    subscriber: str = ""
    onu_id: int | None = None
    created_at: datetime
    updated_at: datetime
    resolved_at: datetime | None = None


class AcsDeviceOut(BaseModel):
    id: int
    serial_number: str = ""
    manufacturer: str = ""
    oui: str = ""
    product_class: str = ""
    model_name: str = ""
    hardware_version: str = ""
    software_version: str = ""
    ip: str = ""
    mac: str = ""
    subscriber: str = ""
    onu_id: int | None = None
    online: bool = False
    last_inform: datetime | None = None
    first_seen: datetime | None = None
    last_cpu: float | None = None
    last_mem_used: float | None = None
    last_mem_total: float | None = None
    last_rx_rate: float | None = None
    last_tx_rate: float | None = None


class AcsParameterOut(BaseModel):
    name: str
    value: str


class AcsMetricOut(BaseModel):
    sampled_at: datetime
    cpu: float | None = None
    mem_used: float | None = None
    mem_total: float | None = None
    rx_rate: float | None = None
    tx_rate: float | None = None


class AcsJobOut(BaseModel):
    id: int
    action: str
    status: str
    result: str = ""
    payload: str = ""
    created_at: datetime
    sent_at: datetime | None = None
    finished_at: datetime | None = None


class AcsWifiBandOut(BaseModel):
    instance: int
    band: str = ""  # 2.4g | 5g | 5g2 | unknown
    ssid: str = ""
    passphrase: str = ""
    enable: bool | None = None
    channel: str = ""
    standard: str = ""
    security_mode: str = ""


class AcsWifiStatusOut(BaseModel):
    supported: bool = False
    bands: list[AcsWifiBandOut] = []
    summary: str = ""


class WifiChangeRequest(BaseModel):
    ssid: str | None = None
    passphrase: str
    enable: bool | None = None
    # Which wireless band(s): 2.4g | 5g | 5g2 | all
    band: str = "2.4g"


class WanConfigRequest(BaseModel):
    addressing_type: str | None = None
    ip_address: str | None = None
    subnet_mask: str | None = None
    default_gateway: str | None = None
    dns_servers: str | None = None
    username: str | None = None
    password: str | None = None


class FirmwareRequest(BaseModel):
    url: str
class OpticalReportRow(BaseModel):
    """One ONU's optical-power summary over the report window (weekly)."""
    olt_id: int = 0
    olt_name: str = ""
    pon_port: str = ""
    onu_id: int = 0
    subscriber: str = ""
    name: str = ""
    serial: str = ""
    samples: int = 0
    avg_rx: float | None = None
    min_rx: float | None = None
    max_rx: float | None = None
    last_rx: float | None = None
    avg_tx: float | None = None
    min_tx: float | None = None
    max_tx: float | None = None
    last_tx: float | None = None
    current_state: str = ""
    bound: bool = False
    first_sampled: datetime | None = None
    last_sampled: datetime | None = None


class OpticalReport(BaseModel):
    window_days: int
    olt_filter: int | None = None
    generated_at: datetime
    rows: list[OpticalReportRow] = []


class FluctuationReportRow(BaseModel):
    """One ONU whose RX power fluctuated more than the threshold."""
    olt_id: int = 0
    olt_name: str = ""
    pon_port: str = ""
    onu_id: int = 0
    subscriber: str = ""
    name: str = ""
    serial: str = ""
    samples: int = 0
    avg_rx: float | None = None
    min_rx: float | None = None
    max_rx: float | None = None
    last_rx: float | None = None
    avg_tx: float | None = None
    fluctuation: float = 0.0  # max_rx - min_rx
    current_state: str = ""


class FluctuationReport(BaseModel):
    window_days: int
    olt_filter: int | None = None
    threshold: float = 3.0
    generated_at: datetime
    rows: list[FluctuationReportRow] = []


class WeakSignalReport(BaseModel):
    olt_filter: int | None = None
    port_filter: str = ""
    limit: int
    generated_at: datetime
    rows: list[WeakOnu] = []


class DowntimeReportRow(BaseModel):
    """Aggregated downtime (down events + outages) per ONU over the window."""
    olt_id: int = 0
    olt_name: str = ""
    pon_port: str = ""
    onu_id: int = 0
    subscriber: str = ""
    name: str = ""
    serial: str = ""
    down_events: int = 0
    outage_events: int = 0
    total_seconds: int = 0
    avg_seconds: int = 0
    max_seconds: int = 0
    reason: str = ""
    first_event: datetime | None = None
    last_event: datetime | None = None


class DowntimeReport(BaseModel):
    window_days: int
    olt_filter: int | None = None
    generated_at: datetime
    rows: list[DowntimeReportRow] = []


class PortReportRow(BaseModel):
    """Per-OLT-port capacity + state aggregation for export."""
    olt_id: int = 0
    olt_name: str = ""
    pon_type: str = ""
    port: str = ""
    label: str = ""
    capacity: int = 0
    used: int = 0
    remaining: int = 0
    active: int = 0
    down: int = 0
    bound: int = 0
    gps: int = 0
    utilization_pct: float = 0.0


class PortReportExport(BaseModel):
    window_days: int = 0
    olt_filter: int | None = None
    generated_at: datetime
    rows: list[PortReportRow] = []


class OnuPortControl(BaseModel):
    olt_id: int
    pon_port: str
    onu_id: int
    port_id: int = 1
    enable: bool


class RejectedOnu(BaseModel):
    olt_id: int
    pon_port: str
    onu_id: int
    serial: str = ""
    reason: str = ""
    raw_line: str = ""
    description: str = ""


class OnuAuthorizeRequest(BaseModel):
    pon_port: str
    onu_id: int
    serial: str
    name: str = ""


# ---------------------------------------------------------------- fiber map
class CableBase(BaseModel):
    code: str
    core_count: int = 12
    manufacturer: str = ""
    manufacturing_year: int = 0
    cable_type: str = "round"
    color: str = ""
    notes: str = ""


class CableCreate(CableBase):
    segments: list["SegmentBase"] = []


class CableUpdate(BaseModel):
    code: str | None = None
    core_count: int | None = None
    manufacturer: str | None = None
    manufacturing_year: int | None = None
    cable_type: str | None = None
    color: str | None = None
    notes: str | None = None
    segments: list["SegmentBase"] | None = None


class SegmentBase(BaseModel):
    start_lat: float
    start_lng: float
    end_lat: float
    end_lng: float
    order_index: int = 0


class SegmentOut(SegmentBase):
    id: int
    cable_id: int


class CableOut(CableBase):
    model_config = ConfigDict(from_attributes=True)

    id: int
    segments: list[SegmentOut] = []


class TjBoxBase(BaseModel):
    name: str
    box_type: str = "tj"
    capacity: int = 4
    tray_count: int = 1
    lat: float
    lng: float
    address: str = ""
    notes: str = ""


class TjBoxCreate(TjBoxBase):
    pass


class TjBoxUpdate(BaseModel):
    name: str | None = None
    box_type: str | None = None
    capacity: int | None = None
    tray_count: int | None = None
    lat: float | None = None
    lng: float | None = None
    address: str | None = None
    notes: str | None = None


class TjBoxOut(TjBoxBase):
    model_config = ConfigDict(from_attributes=True)

    id: int
    unique_id: str


class SplitterBase(BaseModel):
    name: str = ""
    split_ratio: int = 2
    tj_box_id: int | None = None
    input_core: int = 0
    output_cores: str = ""
    lat: float
    lng: float
    notes: str = ""


class SplitterCreate(SplitterBase):
    pass


class SplitterUpdate(BaseModel):
    name: str | None = None
    split_ratio: int | None = None
    tj_box_id: int | None = None
    input_core: int | None = None
    output_cores: str | None = None
    lat: float | None = None
    lng: float | None = None
    notes: str | None = None


class SplitterOut(SplitterBase):
    model_config = ConfigDict(from_attributes=True)

    id: int
    unique_id: str
    tj_box_name: str = ""
